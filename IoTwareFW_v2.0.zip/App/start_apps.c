/*
 * Copyright (C) <2020> <ETRI>
 * This License and Service Agreement (LSA) applies to all works and their derivative works based on source form version and object form version of IoTware Project. Currently, the LSA for IoTware Project has two policies, 'Open Source License' and 'Commercial License'. Therefore, all works including the source code and executable code of IoTware Project and derivative works based thereon are subject to either 'Open Source License' or 'Commercial License' depending on the user's needs and purpose. Details related to the selection of the applicable license are specified in this LSA. If you use any or all of IoTware Project in any form, you are deemed to have consented to this LSA. If you breach any of the terms and conditions set forth in this LSA, you are solely responsible for any losses or damages incurred by Electronics and Communications Research Institute (ETRI), and ETRI assume no responsibility for you or any third party.
 * If you use the source form version or object form version of IoTware Project in whole or in part to develop a code or a derivative work, and you want to commercialize the result in some form, you will be covered under a commercial license. And if you are subject to a commercial license, the contract for the use of IoTware Project is subject to TECHNOLOGY LICENSE AGREEMENT of ETRI. You acknowledge that ETRI has all legal rights, title and interest, including intellectual property rights in the IoTware Project (regardless of whether such intellectual property rights are registered or where such rights exist) and agree with no objection thereto. Except as provided in a subsidiary agreement, nothing in this LSA grants you the right to use IoTware Project or the name, service mark, logo, domain name and other unique identification marks of ETRI.
 * If you use the source form version or object form version of IoTware Project in whole or in part to develop a code or a derivative work, and you do not commercialize the result in any form, you will be covered under an open source license. IoTware Project is in accordance with Free Software Foundation (FSF)'s open source policy, and is allowed to use it in the appropriate scope and manner, and you must comply with the applicable open source license policy applied to IoTware Project. IoTware Project is, in principle, subject to GNU Lesser General Public License version 2.1 (LGPLv2.1). If you have acquired all or a part of the IoTware Project in any way and it is subject to a license other than the open source license described above, please contact the following address for the technical support and other inquiries before use, and check the usage information.
 */

/**
 * @file    start_apps.c
 */

/* Includes */
#include <stdio.h>
#include "iotware_core.h"
#include "interface_all.h"
#include "iw_fw_collabomsg.h"
#include "iw_fw_microservices.h"
#include "iw_fw_lwMsgUtils.h"
#include "ms_generator.h"

/* External functions */
extern void iw_fw_lwMsgTx(void *pvParameters);
extern void iw_fw_lwMsgRx(void *pvParameters);
extern void lwmsg_dist_task(void *pvParameters);

/* Global variables */

#if (defined USE_BLE_MCM || defined USE_LORA_MCM || defined USE_CHELSEA_MCM || defined USE_WIFI_MCM)
iw_task_t	xNetworkRxTask_MCM;		// Network RX task for MCM
iw_queue_t	xNetworkRx_MCM;			// Message queue of network RX task for MCM
iw_task_t	xNetworkTxTask_MCM;		// Network TX task for MCM
iw_queue_t	xNetworkTx_MCM;			// Message queue of network TX task for MCM
#endif /* USE_BLE_MCM || USE_LORA_MCM || USE_CHELSEA_MCM || USE_WIFI_MCM */

#if (defined USE_BLE_DCM || defined USE_LORA_DCM || defined USE_CHELSEA_DCM || defined USE_WIFI_DCM)
iw_task_t	xNetworkRxTask_DCM;		// Network RX task for DCM
iw_queue_t	xNetworkRx_DCM;			// Message queue of the network RX task for DCM
iw_task_t	xNetworkTxTask_DCM;		// Network TX task for DCM
iw_queue_t	xNetworkTx_DCM;			// Message queue of the network TX task for DCM
#endif /* USE_BLE_DCM || USE_LORA_DCM || USE_CHELSEA_DCM || USE_WIFI_DCM */


#if (defined(USE_WIFI_MCM) || defined(USE_WIFI_DCM))
extern void wifi_task(void *);
#endif

#if (defined(USE_BLE_MCM) || defined(USE_BLE_DCM))
extern void ble_task(void *);
#endif

#if (defined(USE_LORA_MCM) || defined(USE_LORA_DCM))
extern void lora_task(void *);
#endif

iw_task_t xNetworkRxTask;

/* Functions */

/**
 * @brief OS에서 로드하는 사용자 응용 프로그램의 시작 지점
 * @details OS에서 로드하는 사용자 응용 프로그램의 시작 지점으로 시동 시 
 * 필요로 하는 사용자 응용 프로그램을 여기서 구동
 */
void start_apps(void)
{
	// temp

#if (defined USE_BLE_MCM || defined USE_LORA_MCM || defined USE_CHELSEA_MCM || defined USE_WIFI_MCM)
	xNetworkRx_MCM = create_queue(10, 128 * sizeof(uint8_t));
	xNetworkTx_MCM = create_queue(10, 256 * sizeof(uint8_t));
#endif

#if (defined USE_BLE_DCM || defined USE_LORA_DCM || defined USE_CHELSEA_DCM || defined USE_WIFI_DCM)
	xNetworkRx_DCM = create_queue(10, 128 * sizeof(uint8_t));
	xNetworkTx_DCM = create_queue(10, 256 * sizeof(uint8_t));
#endif

#if defined(USE_BLE_MCM)
	xNetworkTxTask_MCM = create_task(ble_task, "ble_task", IW_MINIMAL_STACK_SIZE, NULL, MS_TASK_PRIORITY, NULL);
#endif
#if defined(USE_BLE_DCM)
	xNetworkTxTask_DCM = create_task(ble_task, "ble_task", IW_MINIMAL_STACK_SIZE, NULL, MS_TASK_PRIORITY, NULL);
#endif

#if defined(USE_LORA_MCM)
	xNetworkTxTask_MCM = create_task(lora_task, "lora_task", IW_MINIMAL_STACK_SIZE, NULL, MS_TASK_PRIORITY, NULL);
#endif
#if defined(USE_LORA_DCM)
	xNetworkTxTask_DCM = create_task(lora_task, "lora_task", IW_MINIMAL_STACK_SIZE, NULL, MS_TASK_PRIORITY, NULL);
#endif

#if defined(USE_CHELSEA_MCM)
	xNetworkTxTask_MCM = create_task(chelsea_task, "chelsea_task", IW_MINIMAL_STACK_SIZE, NULL, MS_TASK_PRIORITY, NULL);
#endif

#if defined(USE_CHELSEA_DCM)
	xNetworkTxTask_DCM = create_task(chelsea_task, "chelsea_task", IW_MINIMAL_STACK_SIZE, NULL, MS_TASK_PRIORITY, NULL);
#endif

#if defined(USE_WIFI_MCM)
	xNetworkTxTask_MCM = create_task(wifi_task, "wifi_task", IW_MINIMAL_STACK_SIZE, NULL, MS_TASK_PRIORITY, NULL);
#endif

#if defined(USE_WIFI_DCM)
	xNetworkTxTask_DCM = create_task(wifi_task, "wifi_task", IW_MINIMAL_STACK_SIZE, NULL, MS_TASK_PRIORITY, NULL);
#endif

	init_mservices();
	NEW_MS_GENERATORS();

	printf("\nEnter to start!\n");
	// getchar();

	set_lwmsg_receive_queue(create_queue(mainQUEUE_LENGTH, sizeof(PLWMessage)));
	set_lwmsg_send_queue(create_queue(mainQUEUE_LENGTH, sizeof(PLWMessage)));

	iw_task_t temp;
	// LWMSG Distribution Task
	temp = create_task(lwmsg_dist_task, "lwmsg_dist_task", IW_MINIMAL_STACK_SIZE * 2, NULL, MS_TASK_PRIORITY+1, NULL);
	set_lwmsg_receive_task(temp);

	temp = create_task(iw_fw_lwMsgTx, "iw_fw_lwMsgTx", IW_MINIMAL_STACK_SIZE * 2, NULL, MS_TASK_PRIORITY+1, NULL);
	set_lwmsg_send_task(temp);

	// FIXME
	xNetworkRxTask = create_task(iw_fw_lwMsgRx, "iw_fw_lwMsgRx", IW_MINIMAL_STACK_SIZE * 2, NULL, MS_TASK_PRIORITY+1, NULL);

	PLWMessage lwm_msg = make_device_registration_lwmsg(1, GET_LWM_TX_DRI());
	if (lwm_msg)
		REQUEST_LWMSG(lwm_msg);

    
#if (IW_MCU_STM32 == 1)	   // STM
	iw_sleep(100);

	uint8_t mro_id = 0;
	iw_error_t succeed = get_sensor_devid(SENSOR_TYPE_ILLUM, NULL, &mro_id);
    if(succeed == IW_SUCCESS)
        set_pwrmode_sensor(mro_id, SENSOR_PWR_RUN_MODE);

	iw_sleep(100);
#elif (IW_MCU_NORDIC == 1) // NORDIC
#else					   // TELECHIPS
#endif
}
