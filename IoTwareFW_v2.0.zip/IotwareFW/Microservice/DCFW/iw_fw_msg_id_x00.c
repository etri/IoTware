#include "iw_fw_msg_id_x00.h"

#pragma pack(push, 1)

static struct CMServerAdvertiseMsg cmSERVER_ADVERTIZE = {
	{
		.ack = CM_ACK_REQ_MSG,
		.message_id = CM_MSG_ID_SERVER_ADVERTISE,
		.dup = 0,
		.qos = CM_QOS_ACK_NONE
	}
};

#pragma pack(pop)

uint8_t *cm_msg_x00_serialize(const struct CMServerAdvertiseMsg *msg, size_t *size)
{
	return cm_header_serialize(&msg->header, size);
}

struct CMServerAdvertiseMsg cm_msg_x00_parse(const uint8_t *msg, const size_t size)
{
	struct CMServerAdvertiseMsg buf;
	buf.header = cm_header_parse(msg, size);
	return buf;
}

struct CMServerAdvertiseMsg cm_msg_x00()
{
	return cmSERVER_ADVERTIZE;
}
