#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMServerAdvertiseMsg {
	struct CMFixedHeader header;
};

#pragma pack(pop)

uint8_t *cm_msg_x00_serialize(const struct CMServerAdvertiseMsg *msg, size_t *size);
struct CMServerAdvertiseMsg cm_msg_x00_parse(const uint8_t *msg, const size_t size);
struct CMServerAdvertiseMsg cm_msg_x00();
