#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMConnectMsg {
	struct CMFixedHeader header;
	uint8_t reserved : 2;
	uint8_t length : 6;
	uint8_t protocol_version : 4;
	uint8_t id_flag : 1;
	uint8_t pwd_flag : 1;
	uint8_t undefined : 2;
	uint8_t keep_alive;
	// uint8_t *optional_payload;
};

struct CMConnectAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x02_serialize(const struct CMConnectMsg *msg, size_t *size);
struct CMConnectMsg cm_msg_x02_parse(const uint8_t *msg, const size_t size);
struct CMConnectMsg cm_msg_x02();
uint8_t *cm_msg_x02_ack_serialize(const struct CMConnectAckMsg *msg, size_t *size);
struct CMConnectAckMsg cm_msg_x02_ack_parse(const uint8_t *msg, const size_t size);
struct CMConnectAckMsg cm_msg_x02_ack();
