#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMMemberInfoPayload {
	uint8_t task_id;
	uint8_t object_id : 6;
	uint8_t attr_count : 2;
	struct CMAttributePayload *attributes;
};

struct CMMemberInfoMsg {
	struct CMFixedHeader header;
	uint8_t reserved : 2;
	uint8_t length : 6;
	struct CMMemberInfoPayload *payload;
};

struct CMMemberInfoAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x03_serialize(const struct CMMemberInfoMsg *msg, size_t *size);
struct CMMemberInfoMsg cm_msg_x03_parse(const uint8_t *msg, const size_t size);
struct CMMemberInfoMsg cm_msg_x03();
uint8_t *cm_msg_x03_ack_serialize(const struct CMMemberInfoAckMsg *msg, size_t *size);
struct CMMemberInfoAckMsg cm_msg_x03_ack_parse(const uint8_t *msg, const size_t size);
struct CMMemberInfoAckMsg cm_msg_x03_ack();
