#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

enum CM_SET_DEVICE_MODE {
	CM_SET_DEVICE_MODE_SLEEP = 0 << 0,
	CM_SET_DEVICE_MODE_SLEEP_TASK = 0 << 1,
	CM_SET_DEVICE_MODE_CLUSTER_HEADER = 0 << 2,
	CM_SET_DEVICE_MODE_UNDEFINED = 0 << 3,
};

struct CMSetDeviceModeMsg {
	struct CMFixedHeader header;
	uint8_t reserved : 2;
	uint8_t length : 6;
	uint8_t mode : 2;
	uint8_t wake_up_interval : 6;
};

struct CMSetDeviceModeAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x04_serialize(const struct CMSetDeviceModeMsg *msg, size_t *size);
struct CMSetDeviceModeMsg cm_msg_x04_parse(const uint8_t *msg, const size_t size);
struct CMSetDeviceModeMsg cm_msg_x04();
uint8_t *cm_msg_x04_ack_serialize(const struct CMSetDeviceModeAckMsg *msg, size_t *size);
struct CMSetDeviceModeAckMsg cm_msg_x04_ack_parse(const uint8_t *msg, const size_t size);
struct CMSetDeviceModeAckMsg cm_msg_x04_ack();
