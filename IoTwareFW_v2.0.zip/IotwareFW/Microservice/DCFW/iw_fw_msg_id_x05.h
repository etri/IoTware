#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

enum CM_CHECK_STATUS {
	CM_CHECK_STATUS_SLEEP = 0 << 0,
	CM_CHECK_STATUS_WAKE_UP = 0 << 1,
	CM_CHECK_STATUS_UNDEFINED1 = 0 << 2,
	CM_CHECK_STATUS_UNDEFINED2 = 0 << 3,
};

struct CMCheckStatusMsg {
	struct CMFixedHeader header;
};

struct CMCheckStatusAckMsg {
	struct CMDefaultAckMsg header;
	uint8_t reserved : 2;
	uint8_t length : 6;
	uint8_t status : 2;
	uint8_t wake_up_interval : 6;
};

#pragma pack(pop)

uint8_t *cm_msg_x05_serialize(const struct CMCheckStatusMsg *msg, size_t *size);
struct CMCheckStatusMsg cm_msg_x05_parse(const uint8_t *msg, const size_t size);
struct CMCheckStatusMsg cm_msg_x05();
uint8_t *cm_msg_x05_ack_serialize(const struct CMCheckStatusAckMsg *msg, size_t *size);
struct CMCheckStatusAckMsg cm_msg_x05_ack_parse(const uint8_t *msg, const size_t size);
struct CMCheckStatusAckMsg cm_msg_x05_ack();
