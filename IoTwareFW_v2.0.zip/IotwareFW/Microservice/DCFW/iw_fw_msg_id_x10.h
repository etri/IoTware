#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMTaskCreationMsg {
	struct CMFixedHeader header;
	uint8_t reserved : 2;
	uint8_t length : 6;
	uint8_t *tasks;
};

struct CMTaskCreationAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x10_serialize(const struct CMTaskCreationMsg *msg, size_t *size);
struct CMTaskCreationMsg cm_msg_x10_parse(const uint8_t *msg, const size_t size);
struct CMTaskCreationMsg cm_msg_x10();
uint8_t *cm_msg_x10_ack_serialize(const struct CMTaskCreationAckMsg *msg, size_t *size);
struct CMTaskCreationAckMsg cm_msg_x10_ack_parse(const uint8_t *msg, const size_t size);
struct CMTaskCreationAckMsg cm_msg_x10_ack();
