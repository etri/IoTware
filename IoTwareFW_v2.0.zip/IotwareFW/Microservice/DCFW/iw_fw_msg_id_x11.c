#include "iw_fw_msg_id_x11.h"

#pragma pack(push, 1)

static struct CMTaskRunAllMsg cmTASK_RUN_ALL = {
	{
		.ack = CM_ACK_REQ_MSG,
		.message_id = CM_MSG_ID_TASK_RUN_ALL,
		.dup = 0,
		.qos = CM_QOS_ACK_NEED
	}
};

static struct CMTaskRunAllAckMsg cmTASK_RUN_ALL_ACK = {
	{
		.ack = CM_ACK_MSG_ID,
		.message_id = CM_MSG_ID_TASK_RUN_ALL,
		.dup = 0,
		.qos = CM_QOS_ACK_NONE,
		.reserved = 0,
		.return_code = 0
	}
};

#pragma pack(pop)

uint8_t *cm_msg_x11_serialize(const struct CMTaskRunAllMsg *msg, size_t *size)
{
	return cm_header_serialize(&msg->header, size);
}

struct CMTaskRunAllMsg cm_msg_x11_parse(const uint8_t *msg, const size_t size)
{
	struct CMTaskRunAllMsg buf;
	buf.header = cm_header_parse(msg, size);
	return buf;
}

struct CMTaskRunAllMsg cm_msg_x11()
{
	return cmTASK_RUN_ALL;
}

uint8_t *cm_msg_x11_ack_serialize(const struct CMTaskRunAllAckMsg *msg, size_t *size)
{
	return cm_default_ack_serialize(&msg->header, size);
}

struct CMTaskRunAllAckMsg cm_msg_x11_ack_parse(const uint8_t *msg, const size_t size)
{
	struct CMTaskRunAllAckMsg buf;
	buf.header = cm_default_ack_parse(msg, size);
	return buf;
}

struct CMTaskRunAllAckMsg cm_msg_x11_ack()
{
	return cmTASK_RUN_ALL_ACK;
}
