#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMTaskRunAllMsg {
	struct CMFixedHeader header;
};

struct CMTaskRunAllAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x11_serialize(const struct CMTaskRunAllMsg *msg, size_t *size);
struct CMTaskRunAllMsg cm_msg_x11_parse(const uint8_t *msg, const size_t size);
struct CMTaskRunAllMsg cm_msg_x11();
uint8_t *cm_msg_x11_ack_serialize(const struct CMTaskRunAllAckMsg *msg, size_t *size);
struct CMTaskRunAllAckMsg cm_msg_x11_ack_parse(const uint8_t *msg, const size_t size);
struct CMTaskRunAllAckMsg cm_msg_x11_ack();
