#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMTaskStopAllMsg {
	struct CMFixedHeader header;
};

struct CMTaskStopAllAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x12_serialize(const struct CMTaskStopAllMsg *msg, size_t *size);
struct CMTaskStopAllMsg cm_msg_x12_parse(const uint8_t *msg, const size_t size);
struct CMTaskStopAllMsg cm_msg_x12();
uint8_t *cm_msg_x12_ack_serialize(const struct CMTaskStopAllAckMsg *msg, size_t *size);
struct CMTaskStopAllAckMsg cm_msg_x12_ack_parse(const uint8_t *msg, const size_t size);
struct CMTaskStopAllAckMsg cm_msg_x12_ack();
