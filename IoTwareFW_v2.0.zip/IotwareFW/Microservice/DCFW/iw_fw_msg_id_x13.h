#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMTaskRunMsg {
	struct CMFixedHeader header;
	uint8_t reserved : 2;
	uint8_t length : 6;
	uint8_t *tasks;
};

struct CMTaskRunAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x13_serialize(const struct CMTaskRunMsg *msg, size_t *size);
struct CMTaskRunMsg cm_msg_x13_parse(const uint8_t *msg, const size_t size);
struct CMTaskRunMsg cm_msg_x13();
uint8_t *cm_msg_x13_ack_serialize(const struct CMTaskRunAckMsg *msg, size_t *size);
struct CMTaskRunAckMsg cm_msg_x13_ack_parse(const uint8_t *msg, const size_t size);
struct CMTaskRunAckMsg cm_msg_x13_ack();
