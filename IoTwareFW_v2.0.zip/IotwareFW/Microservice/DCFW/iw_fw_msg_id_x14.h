#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMTaskStopMsg {
	struct CMFixedHeader header;
	uint8_t reserved : 2;
	uint8_t length : 6;
	uint8_t *tasks;
};

struct CMTaskStopAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x14_serialize(const struct CMTaskStopMsg *msg, size_t *size);
struct CMTaskStopMsg cm_msg_x14_parse(const uint8_t *msg, const size_t size);
struct CMTaskStopMsg cm_msg_x14();
uint8_t *cm_msg_x14_ack_serialize(const struct CMTaskStopAckMsg *msg, size_t *size);
struct CMTaskStopAckMsg cm_msg_x14_ack_parse(const uint8_t *msg, const size_t size);
struct CMTaskStopAckMsg cm_msg_x14_ack();
