#pragma once

#include "iw_fw_collabomsg_internal.h"

#pragma pack(push, 1)

struct CMTaskOutputDataPayload {
	uint8_t task_id;
	uint8_t object_id : 6;
	uint8_t attr_count : 2;
	struct CMAttributeValuePayload *attribute_values;
};

struct CMTaskOutputDataMsg {
	struct CMFixedHeader header;
	uint8_t reserved : 2;
	uint8_t length : 6;
	struct CMTaskOutputDataPayload *payload;
};

struct CMTaskOutputDataAckMsg {
	struct CMDefaultAckMsg header;
};

#pragma pack(pop)

uint8_t *cm_msg_x18_serialize(const struct CMTaskOutputDataMsg *msg, size_t *size);
struct CMTaskOutputDataMsg cm_msg_x18_parse(const uint8_t *msg, const size_t size);
struct CMTaskOutputDataMsg cm_msg_x18();
uint8_t *cm_msg_x18_ack_serialize(const struct CMTaskOutputDataAckMsg *msg, size_t *size);
struct CMTaskOutputDataAckMsg cm_msg_x18_ack_parse(const uint8_t *msg, const size_t size);
struct CMTaskOutputDataAckMsg cm_msg_x18_ack();
