
#ifndef SERVICE_H
#define SERVICE_H

unsigned char get_lowbattery_control(void);
#if 0
unsigned char get_lowsignal_control(void);
#endif
unsigned char get_lowpower_scene_control(void);
#endif /* SERVICE_H */