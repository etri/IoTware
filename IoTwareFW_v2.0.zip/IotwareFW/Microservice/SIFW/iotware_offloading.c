#include "iotware_offloading.h"

#ifdef IW_OFFLOADING_MS
#else
#endif
