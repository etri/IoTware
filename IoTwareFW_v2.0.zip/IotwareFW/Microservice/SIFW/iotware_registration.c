#include "iotware_registration.h"

#ifdef IW_REGISTRATION_MS
#else
#endif
