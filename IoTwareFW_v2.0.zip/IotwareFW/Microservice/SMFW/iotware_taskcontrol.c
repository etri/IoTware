/*
 * Copyright (C) <2020> <ETRI>
 * This License and Service Agreement (LSA) applies to all works and their derivative works based on source form version and object form version of IoTware Project. Currently, the LSA for IoTware Project has two policies, 'Open Source License' and 'Commercial License'. Therefore, all works including the source code and executable code of IoTware Project and derivative works based thereon are subject to either 'Open Source License' or 'Commercial License' depending on the user's needs and purpose. Details related to the selection of the applicable license are specified in this LSA. If you use any or all of IoTware Project in any form, you are deemed to have consented to this LSA. If you breach any of the terms and conditions set forth in this LSA, you are solely responsible for any losses or damages incurred by Electronics and Communications Research Institute (ETRI), and ETRI assume no responsibility for you or any third party.
 * If you use the source form version or object form version of IoTware Project in whole or in part to develop a code or a derivative work, and you want to commercialize the result in some form, you will be covered under a commercial license. And if you are subject to a commercial license, the contract for the use of IoTware Project is subject to TECHNOLOGY LICENSE AGREEMENT of ETRI. You acknowledge that ETRI has all legal rights, title and interest, including intellectual property rights in the IoTware Project (regardless of whether such intellectual property rights are registered or where such rights exist) and agree with no objection thereto. Except as provided in a subsidiary agreement, nothing in this LSA grants you the right to use IoTware Project or the name, service mark, logo, domain name and other unique identification marks of ETRI.
 * If you use the source form version or object form version of IoTware Project in whole or in part to develop a code or a derivative work, and you do not commercialize the result in any form, you will be covered under an open source license. IoTware Project is in accordance with Free Software Foundation (FSF)'s open source policy, and is allowed to use it in the appropriate scope and manner, and you must comply with the applicable open source license policy applied to IoTware Project. IoTware Project is, in principle, subject to GNU Lesser General Public License version 2.1 (LGPLv2.1). If you have acquired all or a part of the IoTware Project in any way and it is subject to a license other than the open source license described above, please contact the following address for the technical support and other inquiries before use, and check the usage information.
 */

#include "iotware_taskcontrol.h"

#ifdef IW_TASKCTRL_MS

#include "iw_fw_microservices.h"

static void *_safe_alloc(const size_t __sz)
{
	if (__sz == 0)
		return NULL;

	void *v = malloc(__sz);
	if (v == NULL)
		return NULL;

	ZeroMemory(v, __sz);
	return v;
}

static void _safe_free(void **p)
{
	if (*p)
		free(*p);
	*p = NULL;
}

/**
 * @brief 다중 입력, 다중 출력이 가능한 Base Task
 * @details 
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
// static iw_queue_t queueset[_p_IN_CNT];
// char buf[512];

void base_task_type1(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;
    int i;

// 	for (i = 0; i < _p_IN_CNT; i++)
// 	{
// 	    queueset[i] = _p_IN_QH[i];
// 	}

	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
		
		pparam->queue_num = -1;
		for (i = 0; i < _p_IN_CNT; i++) 
		{
		    if ( IW_SUCCESS == recv_queue((iw_queue_t)_p_IN_QH[i], &pparam->input_info, false) )
		    {
		        pparam->queue_num = i;
		        SET_TASK_RUNNING(tp);
			    STProcessingReturn beforeReturn;
			    STProcessingReturn afterReturn;
			    memset(&beforeReturn, 0, sizeof(STProcessingReturn));
			    memset(&afterReturn, 0, sizeof(STProcessingReturn));

			    if (tp->before_fn)
				    beforeReturn = tp->before_fn(pparam);
			    if (beforeReturn.user_data)
			    {
				    SEND_OUT_QH(_p_OUT_CNT);
				    beforeReturn.user_data = NULL;
			    }
			    if (tp->after_fn)
				    afterReturn = tp->after_fn(pparam);
				break;
		    }
		}
		
// 		if (-1 == pparam->queue_num)
// 		{
// 			sleep(200);
// 			continue;
// 		}
		
// 		iw_queue_t xActivatedQueue = _p_IN_QH[i];

// 		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info, FALSE);
// 		if (recv == IW_SUCCESS)
// 		{
// 			SET_TASK_RUNNING(tp);
// 			STProcessingReturn beforeReturn;
// 			STProcessingReturn afterReturn;
// 			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
// 			memset(&afterReturn, 0, sizeof(STProcessingReturn));

// 			if (tp->before_fn)
// 				beforeReturn = tp->before_fn(pparam);
// 			if (beforeReturn.user_data)
// 			{
// 				SEND_OUT_QH(_p_OUT_CNT);
// 				beforeReturn.user_data = NULL;
// 			}
// 			if (tp->after_fn)
// 				afterReturn = tp->after_fn(pparam);
// 		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief 단일 입력, 다중 출력이 가능한 Base Task
 * @details 
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type2(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);

		pparam->queue_num = 0;
		iw_error_t recv = recv_queue(_p_IN_QH[pparam->queue_num], &pparam->input_info, TRUE);
		if (recv == IW_SUCCESS)
		{
			SET_TASK_RUNNING(tp);
			STProcessingReturn beforeReturn;
			STProcessingReturn afterReturn;
			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
			memset(&afterReturn, 0, sizeof(STProcessingReturn));

			if (tp->before_fn)
				beforeReturn = tp->before_fn(pparam);
			if (beforeReturn.user_data)
			{
				SEND_OUT_QH(_p_OUT_CNT);
				beforeReturn.user_data = NULL;
			}
			if (tp->after_fn)
				afterReturn = tp->after_fn(pparam);
		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief Task 실행과 함께 sleep_ms 간격으로 sleep_count만큼 반복하는 Base Task
 * @details 무입력, 반복 출력
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type3(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	SET_TASK_WAITING(tp);
	pparam->queue_num = -1;

	sleep(200);

	uint32_t sleep_count = 0;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_RUNNING(tp);
		STProcessingReturn beforeReturn;
		STProcessingReturn afterReturn;
		memset(&beforeReturn, 0, sizeof(STProcessingReturn));
		memset(&afterReturn, 0, sizeof(STProcessingReturn));

		++sleep_count;
		if (pparam->total_sleep_count != 0 && sleep_count > pparam->total_sleep_count)
			break;

		if (tp->before_fn)
			beforeReturn = tp->before_fn(pparam);
		if (beforeReturn.user_data)
		{
			SEND_OUT_QH(_p_OUT_CNT);
			beforeReturn.user_data = NULL;
		}
		if (tp->after_fn)
			afterReturn = tp->after_fn(pparam);

		sleep(pparam->sleep_ms);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief 입력을 받은 이후 sleep_ms 간격으로 sleep_count만큼 반복하는 Base Task
 * @details 다중 입력, 반복 출력
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type4(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

// 	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
// 	for (int i = 0; i < _p_IN_CNT; i++)
// 		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

// 	QueueHandle_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
// 		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
// 		if (xActivatedQueue == NULL)
// 		{
// 			sleep(200);
// 			continue;
// 		}

		pparam->queue_num = -1;
		for (int i = 0; i < _p_IN_CNT; i++) {
		    if (IW_SUCCESS == recv_queue((iw_queue_t)_p_IN_QH[i], &pparam->input_info, FALSE)) {
                SET_TASK_RUNNING(tp);
    			iw_tick_t xFirstWakeTime = get_tick_count();
    			uint32_t sleep_count = 0;
    
    			do
    			{
    				STProcessingReturn beforeReturn;
    				STProcessingReturn afterReturn;
    				memset(&beforeReturn, 0, sizeof(STProcessingReturn));
    				memset(&afterReturn, 0, sizeof(STProcessingReturn));
    
    				iw_tick_t xMaxPeriod = IW_MS_TO_TICKS(pparam->total_sleep_ms * 1000);
    				iw_tick_t xCurrWakeTime = get_tick_count();
    				if (xMaxPeriod != 0 && (xCurrWakeTime - xFirstWakeTime) >= xMaxPeriod)
    					break;
    
    				++sleep_count;
    				if (pparam->total_sleep_count != 0 && sleep_count > pparam->total_sleep_count)
    					break;
    
    				if (tp->state == STOPPED)
    				{
    					_DPRINT(tp, "%s Task Stopped\n", tp->name);
    					break;
    				}
    
    				if (tp->before_fn)
    					beforeReturn = tp->before_fn(pparam);
    				if (beforeReturn.user_data)
    				{
    					SEND_OUT_QH(_p_OUT_CNT);
    					beforeReturn.user_data = NULL;
    				}
    				if (tp->after_fn)
    					afterReturn = tp->after_fn(pparam);
    
    				sleep(pparam->sleep_ms);
    			} while (TRUE);
				
				pparam->queue_num = i;
				break;   
		    }
// 			if (_p_IN_QH[i] == xActivatedQueue)
// 			{
// 				pparam->queue_num = i;
// 				break;
// 			}
		}
// 		if (pparam->queue_num == -1)
// 			continue;

// 		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info, FALSE);
// 		if (recv == IW_SUCCESS)
// 		{
// 			SET_TASK_RUNNING(tp);
// 			iw_tick_t xFirstWakeTime = get_tick_count();
// 			uint32_t sleep_count = 0;

// 			do
// 			{
// 				STProcessingReturn beforeReturn;
// 				STProcessingReturn afterReturn;
// 				memset(&beforeReturn, 0, sizeof(STProcessingReturn));
// 				memset(&afterReturn, 0, sizeof(STProcessingReturn));

// 				iw_tick_t xMaxPeriod = IW_MS_TO_TICKS(pparam->total_sleep_ms * 1000);
// 				iw_tick_t xCurrWakeTime = get_tick_count();
// 				if (xMaxPeriod != 0 && (xCurrWakeTime - xFirstWakeTime) >= xMaxPeriod)
// 					break;

// 				++sleep_count;
// 				if (pparam->total_sleep_count != 0 && sleep_count > pparam->total_sleep_count)
// 					break;

// 				if (tp->state == STOPPED)
// 				{
// 					_DPRINT(tp, "%s Task Stopped\n", tp->name);
// 					break;
// 				}

// 				if (tp->before_fn)
// 					beforeReturn = tp->before_fn(pparam);
// 				if (beforeReturn.user_data)
// 				{
// 					SEND_OUT_QH(_p_OUT_CNT);
// 					beforeReturn.user_data = NULL;
// 				}
// 				if (tp->after_fn)
// 					afterReturn = tp->after_fn(pparam);

// 				sleep(pparam->sleep_ms);
// 			} while (TRUE);
// 		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief MCMSG 다중 입력, 다중 출력이 가능한 Base Task
 * @details PLWMessage 구조체를 수신하여 Response 메시지 전송
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type5(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

// 	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
// 	for (int i = 0; i < _p_IN_CNT; i++)
// 		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

// 	QueueHandle_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
// 		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
// 		if (xActivatedQueue == NULL)
// 		{
// 			sleep(200);
// 			continue;
// 		}

		pparam->queue_num = -1;
		for (int i = 0; i < _p_IN_CNT; i++) {
		    if (IW_SUCCESS == recv_queue((iw_queue_t)_p_IN_QH[i], &pparam->input_info->input_data, FALSE)) {
			    SET_TASK_RUNNING(tp);
    			STProcessingReturn beforeReturn;
    			STProcessingReturn afterReturn;
    			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
    			memset(&afterReturn, 0, sizeof(STProcessingReturn));
    
    			if (tp->before_fn)
    				beforeReturn = tp->before_fn(pparam);
    			if (beforeReturn.user_data)
    			{
    				SEND_OUT_QH(_p_OUT_CNT);
    				beforeReturn.user_data = NULL;
    			}
    			if (tp->after_fn)
    				afterReturn = tp->after_fn(pparam);
			    
				pparam->queue_num = i;
				break;
			}
		}
// 		if (pparam->queue_num == -1)
// 			continue;

// 		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info->input_data, FALSE);
// 		if (recv == IW_SUCCESS)
// 		{
// 			SET_TASK_RUNNING(tp);
// 			STProcessingReturn beforeReturn;
// 			STProcessingReturn afterReturn;
// 			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
// 			memset(&afterReturn, 0, sizeof(STProcessingReturn));

// 			if (tp->before_fn)
// 				beforeReturn = tp->before_fn(pparam);
// 			if (beforeReturn.user_data)
// 			{
// 				SEND_OUT_QH(_p_OUT_CNT);
// 				beforeReturn.user_data = NULL;
// 			}
// 			if (tp->after_fn)
// 				afterReturn = tp->after_fn(pparam);
// 		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief MCMSG의 Response 메시지 전송을 위한 Base Task
 * @details PLWMessage 구조체를 수신하여 Response 메시지 전송
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type6(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

// 	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
// 	for (int i = 0; i < _p_IN_CNT; i++)
// 		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

	iw_queue_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
// 		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
// 		if (xActivatedQueue == NULL)
// 		{
// 			sleep(200);
// 			continue;
// 		}

// 		pparam->queue_num = -1;
// 		for (int i = 0; i < _p_IN_CNT; i++)
// 		{
// 			if (_p_IN_QH[i] == xActivatedQueue)
// 			{
// 				pparam->queue_num = i;
// 				break;
// 			}
// 		}
// 		if (pparam->queue_num == -1)
// 			continue;
        pparam->queue_num = -1;
        for (int i = 0; i < _p_IN_CNT; i++) {
            if (IW_SUCCESS == recv_queue(_p_IN_QH[i], &pparam->input_info, FALSE)) {
                SET_TASK_RUNNING(tp);
    			STProcessingReturn beforeReturn;
    			STProcessingReturn afterReturn;
    			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
    			memset(&afterReturn, 0, sizeof(STProcessingReturn));
    
    			if (tp->before_fn)
    				beforeReturn = tp->before_fn(pparam);
    			if (beforeReturn.user_data)
    			{
    				PLWMessage msg = *(PLWMessage *)((PSTProcessingInput)_p_OUT_SIG)->input_data;
    				RESPONSE_LWMSG(msg);
    				beforeReturn.user_data = NULL;
    			}
    			if (tp->after_fn)
    				afterReturn = tp->after_fn(pparam);
                
                pparam->queue_num = i;
                break;
            }
        }

// 		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info, FALSE);
// 		if (recv == IW_SUCCESS)
// 		{
// 			SET_TASK_RUNNING(tp);
// 			STProcessingReturn beforeReturn;
// 			STProcessingReturn afterReturn;
// 			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
// 			memset(&afterReturn, 0, sizeof(STProcessingReturn));

// 			if (tp->before_fn)
// 				beforeReturn = tp->before_fn(pparam);
// 			if (beforeReturn.user_data)
// 			{
// 				PLWMessage msg = *(PLWMessage *)((PSTProcessingInput)_p_OUT_SIG)->input_data;
// 				RESPONSE_LWMSG(msg);
// 				beforeReturn.user_data = NULL;
// 			}
// 			if (tp->after_fn)
// 				afterReturn = tp->after_fn(pparam);
// 		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief MCMSG의 Request 메시지 전송을 위한 전용 Base Task
 * @details PLWMessage 구조체를 수신하여 Request 메시지 전송, Before Function을 사용하지 않음.
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type7(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

// 	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
// 	for (int i = 0; i < _p_IN_CNT; i++)
// 		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

// 	QueueHandle_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
// 		SET_TASK_WAITING(tp);
// 		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
// 		if (xActivatedQueue == NULL)
// 		{
// 			sleep(200);
// 			continue;
// 		}

		pparam->queue_num = -1;
		for (int i = 0; i < _p_IN_CNT; i++) {
		    if (IW_SUCCESS == recv_queue(_p_IN_QH[i], &pparam->input_info, FALSE)) {
		        SET_TASK_RUNNING(tp);
    			STProcessingReturn beforeReturn;
    			STProcessingReturn afterReturn;
    			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
    			memset(&afterReturn, 0, sizeof(STProcessingReturn));
    
                printf("Task Queue Received.\n");
    			if (tp->before_fn)
    				beforeReturn = tp->before_fn(pparam);
    			if (beforeReturn.user_data)
    			{
    				PLWMessage msg = *(PLWMessage *)((PSTProcessingInput)_p_OUT_SIG)->input_data;
    				REQUEST_LWMSG(msg);
    				beforeReturn.user_data = NULL;
    			}
    			if (tp->after_fn)
    				afterReturn = tp->after_fn(pparam);
		        
				pparam->queue_num = i;
				break;
			}
		}
// 		if (pparam->queue_num == -1)
// 			continue;

// 		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info, FALSE);
// 		if (recv == IW_SUCCESS)
// 		{
// 			SET_TASK_RUNNING(tp);
// 			STProcessingReturn beforeReturn;
// 			STProcessingReturn afterReturn;
// 			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
// 			memset(&afterReturn, 0, sizeof(STProcessingReturn));

// 			if (tp->before_fn)
// 				beforeReturn = tp->before_fn(pparam);
// 			if (beforeReturn.user_data)
// 			{
// 				PLWMessage msg = *(PLWMessage *)((PSTProcessingInput)_p_OUT_SIG)->input_data;
// 				REQUEST_LWMSG(msg);
// 				beforeReturn.user_data = NULL;
// 			}
// 			if (tp->after_fn)
// 				afterReturn = tp->after_fn(pparam);
// 		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

#else

void base_task_type1(void *pvParameters) {}
void base_task_type2(void *pvParameters) {}
void base_task_type3(void *pvParameters) {}
void base_task_type4(void *pvParameters) {}
void base_task_type5(void *pvParameters) {}
void base_task_type6(void *pvParameters) {}
void base_task_type7(void *pvParameters) {}

#endif



#if 0

#include "iotware_taskcontrol.h"

#ifdef IW_TASKCTRL_MS

#include "iw_fw_microservices.h"

static void *_safe_alloc(const size_t __sz)
{
	if (__sz == 0)
		return NULL;

	void *v = malloc(__sz);
	if (v == NULL)
		return NULL;

	ZeroMemory(v, __sz);
	return v;
}

static void _safe_free(void **p)
{
	if (*p)
		free(*p);
	*p = NULL;
}

/**
 * @brief 다중 입력, 다중 출력이 가능한 Base Task
 * @details 
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type1(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
	for (int i = 0; i < _p_IN_CNT; i++)
		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

	QueueHandle_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
		if (xActivatedQueue == NULL)
		{
			sleep(200);
			continue;
		}

		pparam->queue_num = -1;
		for (int i = 0; i < _p_IN_CNT; i++)
		{
			if (_p_IN_QH[i] == xActivatedQueue)
			{
				pparam->queue_num = i;
				break;
			}
		}
		if (pparam->queue_num == -1)
			continue;

		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info, FALSE);
		if (recv == IW_SUCCESS)
		{
			SET_TASK_RUNNING(tp);
			STProcessingReturn beforeReturn;
			STProcessingReturn afterReturn;
			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
			memset(&afterReturn, 0, sizeof(STProcessingReturn));

			if (tp->before_fn)
				beforeReturn = tp->before_fn(pparam);
			if (beforeReturn.user_data)
			{
				SEND_OUT_QH(_p_OUT_CNT);
				beforeReturn.user_data = NULL;
			}
			if (tp->after_fn)
				afterReturn = tp->after_fn(pparam);
		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief 단일 입력, 다중 출력이 가능한 Base Task
 * @details 
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type2(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);

		pparam->queue_num = 0;
		iw_error_t recv = recv_queue(_p_IN_QH[pparam->queue_num], &pparam->input_info, TRUE);
		if (recv == IW_SUCCESS)
		{
			SET_TASK_RUNNING(tp);
			STProcessingReturn beforeReturn;
			STProcessingReturn afterReturn;
			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
			memset(&afterReturn, 0, sizeof(STProcessingReturn));

			if (tp->before_fn)
				beforeReturn = tp->before_fn(pparam);
			if (beforeReturn.user_data)
			{
				SEND_OUT_QH(_p_OUT_CNT);
				beforeReturn.user_data = NULL;
			}
			if (tp->after_fn)
				afterReturn = tp->after_fn(pparam);
		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief Task 실행과 함께 sleep_ms 간격으로 sleep_count만큼 반복하는 Base Task
 * @details 무입력, 반복 출력
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type3(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	SET_TASK_WAITING(tp);
	pparam->queue_num = -1;

	sleep(200);

	uint32_t sleep_count = 0;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_RUNNING(tp);
		STProcessingReturn beforeReturn;
		STProcessingReturn afterReturn;
		memset(&beforeReturn, 0, sizeof(STProcessingReturn));
		memset(&afterReturn, 0, sizeof(STProcessingReturn));

		++sleep_count;
		if (pparam->total_sleep_count != 0 && sleep_count > pparam->total_sleep_count)
			break;

		if (tp->before_fn)
			beforeReturn = tp->before_fn(pparam);
		if (beforeReturn.user_data)
		{
			SEND_OUT_QH(_p_OUT_CNT);
			beforeReturn.user_data = NULL;
		}
		if (tp->after_fn)
			afterReturn = tp->after_fn(pparam);

		sleep(pparam->sleep_ms);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief 입력을 받은 이후 sleep_ms 간격으로 sleep_count만큼 반복하는 Base Task
 * @details 다중 입력, 반복 출력
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type4(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
	for (int i = 0; i < _p_IN_CNT; i++)
		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

	QueueHandle_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
		if (xActivatedQueue == NULL)
		{
			sleep(200);
			continue;
		}

		pparam->queue_num = -1;
		for (int i = 0; i < _p_IN_CNT; i++)
		{
			if (_p_IN_QH[i] == xActivatedQueue)
			{
				pparam->queue_num = i;
				break;
			}
		}
		if (pparam->queue_num == -1)
			continue;

		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info, FALSE);
		if (recv == IW_SUCCESS)
		{
			SET_TASK_RUNNING(tp);
			iw_tick_t xFirstWakeTime = get_tick_count();
			uint32_t sleep_count = 0;

			do
			{
				STProcessingReturn beforeReturn;
				STProcessingReturn afterReturn;
				memset(&beforeReturn, 0, sizeof(STProcessingReturn));
				memset(&afterReturn, 0, sizeof(STProcessingReturn));

				iw_tick_t xMaxPeriod = IW_MS_TO_TICKS(pparam->total_sleep_ms * 1000);
				iw_tick_t xCurrWakeTime = get_tick_count();
				if (xMaxPeriod != 0 && (xCurrWakeTime - xFirstWakeTime) >= xMaxPeriod)
					break;

				++sleep_count;
				if (pparam->total_sleep_count != 0 && sleep_count > pparam->total_sleep_count)
					break;

				if (tp->state == STOPPED)
				{
					_DPRINT(tp, "%s Task Stopped\n", tp->name);
					break;
				}

				if (tp->before_fn)
					beforeReturn = tp->before_fn(pparam);
				if (beforeReturn.user_data)
				{
					SEND_OUT_QH(_p_OUT_CNT);
					beforeReturn.user_data = NULL;
				}
				if (tp->after_fn)
					afterReturn = tp->after_fn(pparam);

				sleep(pparam->sleep_ms);
			} while (TRUE);
		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief MCMSG 다중 입력, 다중 출력이 가능한 Base Task
 * @details PLWMessage 구조체를 수신하여 Response 메시지 전송
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type5(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
	for (int i = 0; i < _p_IN_CNT; i++)
		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

	QueueHandle_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
		if (xActivatedQueue == NULL)
		{
			sleep(200);
			continue;
		}

		pparam->queue_num = -1;
		for (int i = 0; i < _p_IN_CNT; i++)
		{
			if (_p_IN_QH[i] == xActivatedQueue)
			{
				pparam->queue_num = i;
				break;
			}
		}
		if (pparam->queue_num == -1)
			continue;

		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info->input_data, FALSE);
		if (recv == IW_SUCCESS)
		{
			SET_TASK_RUNNING(tp);
			STProcessingReturn beforeReturn;
			STProcessingReturn afterReturn;
			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
			memset(&afterReturn, 0, sizeof(STProcessingReturn));

			if (tp->before_fn)
				beforeReturn = tp->before_fn(pparam);
			if (beforeReturn.user_data)
			{
				SEND_OUT_QH(_p_OUT_CNT);
				beforeReturn.user_data = NULL;
			}
			if (tp->after_fn)
				afterReturn = tp->after_fn(pparam);
		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief MCMSG의 Response 메시지 전송을 위한 Base Task
 * @details PLWMessage 구조체를 수신하여 Response 메시지 전송
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type6(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
	for (int i = 0; i < _p_IN_CNT; i++)
		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

	QueueHandle_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
		if (xActivatedQueue == NULL)
		{
			sleep(200);
			continue;
		}

		pparam->queue_num = -1;
		for (int i = 0; i < _p_IN_CNT; i++)
		{
			if (_p_IN_QH[i] == xActivatedQueue)
			{
				pparam->queue_num = i;
				break;
			}
		}
		if (pparam->queue_num == -1)
			continue;

		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info, FALSE);
		if (recv == IW_SUCCESS)
		{
			SET_TASK_RUNNING(tp);
			STProcessingReturn beforeReturn;
			STProcessingReturn afterReturn;
			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
			memset(&afterReturn, 0, sizeof(STProcessingReturn));

			if (tp->before_fn)
				beforeReturn = tp->before_fn(pparam);
			if (beforeReturn.user_data)
			{
				PLWMessage msg = *(PLWMessage *)((PSTProcessingInput)_p_OUT_SIG)->input_data;
				RESPONSE_LWMSG(msg);
				beforeReturn.user_data = NULL;
			}
			if (tp->after_fn)
				afterReturn = tp->after_fn(pparam);
		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

/**
 * @brief MCMSG의 Request 메시지 전송을 위한 전용 Base Task
 * @details PLWMessage 구조체를 수신하여 Request 메시지 전송, Before Function을 사용하지 않음.
 * @param void *pvParameters  
 * @return 
 * @author ETRI
 */
void base_task_type7(void *pvParameters)
{
	PSTProcessingParam pparam = (PSTProcessingParam)pvParameters;
	IW_TASK_STRUCT *tp = pparam->task_info;

	QueueSetHandle_t xQueueSet = xQueueCreateSet(setpollQUEUE_LENGTH);
	for (int i = 0; i < _p_IN_CNT; i++)
		xQueueAddToSet(_p_IN_QH[i], xQueueSet);

	QueueHandle_t xActivatedQueue = NULL;
	int loop_condition = TRUE;
	while (loop_condition == TRUE)
	{
		SET_TASK_WAITING(tp);
		xActivatedQueue = xQueueSelectFromSet(xQueueSet, setpollDONT_BLOCK);
		if (xActivatedQueue == NULL)
		{
			sleep(200);
			continue;
		}

		pparam->queue_num = -1;
		for (int i = 0; i < _p_IN_CNT; i++)
		{
			if (_p_IN_QH[i] == xActivatedQueue)
			{
				pparam->queue_num = i;
				break;
			}
		}
		if (pparam->queue_num == -1)
			continue;

		iw_error_t recv = recv_queue(xActivatedQueue, &pparam->input_info, FALSE);
		if (recv == IW_SUCCESS)
		{
			SET_TASK_RUNNING(tp);
			STProcessingReturn beforeReturn;
			STProcessingReturn afterReturn;
			memset(&beforeReturn, 0, sizeof(STProcessingReturn));
			memset(&afterReturn, 0, sizeof(STProcessingReturn));

			if (tp->before_fn)
				beforeReturn = tp->before_fn(pparam);
			if (beforeReturn.user_data)
			{
				PLWMessage msg = *(PLWMessage *)((PSTProcessingInput)_p_OUT_SIG)->input_data;
				REQUEST_LWMSG(msg);
				beforeReturn.user_data = NULL;
			}
			if (tp->after_fn)
				afterReturn = tp->after_fn(pparam);
		}

		sleep(200);
	}

	_safe_free(&pparam->user_data);
	_safe_free(&pparam->input_info->input_data);
	_safe_free((void **)&pparam->input_info);
	tp->state = STOPPED;
	free(pparam);
}

#else

void base_task_type1(void *pvParameters) {}
void base_task_type2(void *pvParameters) {}
void base_task_type3(void *pvParameters) {}
void base_task_type4(void *pvParameters) {}
void base_task_type5(void *pvParameters) {}
void base_task_type6(void *pvParameters) {}
void base_task_type7(void *pvParameters) {}

#endif

#endif