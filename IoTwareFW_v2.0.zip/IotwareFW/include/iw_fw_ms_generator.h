#pragma once

#include "iw_fw_microservices.h"

// IDE를 통해 자동으로 생성되는 파일입니다.

FN_PROTOTYPE_MAKE_MS(test_ums);

#define NEW_MS_GENERATORS() \
	ADD_NEW_MICRO_SERVICE(test_ums, "101");

