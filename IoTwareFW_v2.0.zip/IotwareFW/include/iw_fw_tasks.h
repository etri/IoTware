#pragma once

#include "iw_fw_microservices.h"

// IDE를 통해 자동으로 생성되는 파일입니다.

FN_PROTOTYPE_TASK(lwmsg_input);
FN_PROTOTYPE_TASK(observing_task);
FN_PROTOTYPE_TASK(sensing_task);
FN_PROTOTYPE_TASK(average_task);
FN_PROTOTYPE_TASK(lwmsg_output);
FN_PROTOTYPE_TASK(lwmsg_response);
FN_PROTOTYPE_TASK(debug_print);
