/*
 * Copyright (C) <2020> <ETRI>
 * This License and Service Agreement (LSA) applies to all works and their derivative works based on source form version and object form version of IoTware Project. Currently, the LSA for IoTware Project has two policies, 'Open Source License' and 'Commercial License'. Therefore, all works including the source code and executable code of IoTware Project and derivative works based thereon are subject to either 'Open Source License' or 'Commercial License' depending on the user's needs and purpose. Details related to the selection of the applicable license are specified in this LSA. If you use any or all of IoTware Project in any form, you are deemed to have consented to this LSA. If you breach any of the terms and conditions set forth in this LSA, you are solely responsible for any losses or damages incurred by Electronics and Communications Research Institute (ETRI), and ETRI assume no responsibility for you or any third party.
 * If you use the source form version or object form version of IoTware Project in whole or in part to develop a code or a derivative work, and you want to commercialize the result in some form, you will be covered under a commercial license. And if you are subject to a commercial license, the contract for the use of IoTware Project is subject to TECHNOLOGY LICENSE AGREEMENT of ETRI. You acknowledge that ETRI has all legal rights, title and interest, including intellectual property rights in the IoTware Project (regardless of whether such intellectual property rights are registered or where such rights exist) and agree with no objection thereto. Except as provided in a subsidiary agreement, nothing in this LSA grants you the right to use IoTware Project or the name, service mark, logo, domain name and other unique identification marks of ETRI.
 * If you use the source form version or object form version of IoTware Project in whole or in part to develop a code or a derivative work, and you do not commercialize the result in any form, you will be covered under an open source license. IoTware Project is in accordance with Free Software Foundation (FSF)'s open source policy, and is allowed to use it in the appropriate scope and manner, and you must comply with the applicable open source license policy applied to IoTware Project. IoTware Project is, in principle, subject to GNU Lesser General Public License version 2.1 (LGPLv2.1). If you have acquired all or a part of the IoTware Project in any way and it is subject to a license other than the open source license described above, please contact the following address for the technical support and other inquiries before use, and check the usage information.
 */

#include "bsp_main.h"
#include "bsp_sc16is740.h"


#ifdef __GNUC__

/**
 * Minimal implementations  for newlib
 */

#include <sys/stat.h>


extern int errno;
#if 1 /* not used by ys */
int _close(int fd)
{
    return -1;
}

int _fstat(int fd, struct stat *st)
{
    st->st_mode = S_IFCHR;
    return 0;
}

int _isatty(int fd)
{
    return 1;
}

int _write (int fd, char *ptr, int len)
{
	static int och = 0;
	for (int i = 0; i < len; i++)
	{
		int ch = (int)(ptr[i] & 0xff);
		if (ch == '\n' && och != '\r')
        	bsp_putc_uart(0, '\r');
		och = ch;
        bsp_putc_uart(0, ch);
	}
    return len;
}

int _read(int fd, char *ptr, int len)
{
	int i = 0; while (i < len)
	{
		char ch = 0;
		if (! bsp_getc_uart(DEBUG_UART_PORT, &ch))
		{
			if (ch == 0x7f)
			{
				if (i > 0)
				{
					i--;
					_write(0, (char *)&ch, 1);
				}
				continue;
			}
			if (ch == '\r') ch = '\n';
			_write(0, (char *)&ch, 1);
			ptr[i++] = (char)(ch & 0xff);
			if (ch == '\n') break;
		}
	}
	return (i > 0) ? i : -1;
}

int _lseek(int fd, int ptr, int dir)
{
    return 0;
}

#if( IW_NANOQPLUS != 1 && IW_RIOT != 1 )

caddr_t _sbrk(int incr)
{
    extern uint32_t __UserSpaceStart;
    extern uint32_t __UserSpaceEnd;

	static uint32_t heap_end = 0;

    if (heap_end == 0)
    {
        heap_end = (uint32_t)&__UserSpaceStart;
    }

    uint32_t top = heap_end;

    if ((heap_end + incr) > ((uint32_t)&__UserSpaceEnd))
    {
        return (caddr_t)(-1);
    }

    heap_end += incr;

    return (caddr_t) top;
}

#endif

__attribute__((weak))
int _stat(const char *filepath, struct stat *st)
{
    st->st_mode = S_IFCHR;
    return 0;
}

__attribute__((weak))
void _exit(int status)
{
	(void) status;
    while (1);
}

__attribute__((weak))
int _kill(pid_t pid, int sig)
{
    (void) pid;
    (void) sig;
    errno = -1;
    return -1;
}

__attribute__((weak))
pid_t _getpid(void)
{
    return 1;
}

__attribute__((weak))
pid_t _getpid_r(struct _reent *ptr)
{
    (void) ptr;
    return 1;
}
#endif
#endif //__GNUC__

#include <stdarg.h>

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

I2C_HandleTypeDef hi2c2;
I2C_HandleTypeDef hi2c3;

SPI_HandleTypeDef hspi2;
SPI_HandleTypeDef hspi3;

volatile uint32_t iw_irq_count = 0;
volatile uint32_t iw_idle_count = 0;
volatile uint32_t iw_last_pid = 0;


#if defined(IOTWARE_BOARD)
#define RED_LED_PIN          GPIO_PIN_6
  
void red_led_on(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    __HAL_RCC_GPIOB_CLK_ENABLE();

	GPIO_InitStruct.Pin = GPIO_PIN_6;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	HAL_GPIO_WritePin(GPIOB, RED_LED_PIN, GPIO_PIN_RESET);
}


void download_key_check(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
	static uint32_t once=0;

	__HAL_RCC_GPIOC_CLK_ENABLE();
	/* Configure GPIO pin : PC7_Pin */
	GPIO_InitStruct.Pin = GPIO_PIN_12;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
 
	while(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_12) == GPIO_PIN_RESET) 
	{
	  if(once == 0)
	  {
          red_led_on();
          once=1;
	  }
	  __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	  __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	  __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	  __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	  __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	}
}
/* added by ys */
#elif defined(DISPOSAL_IOT_BOARD)
#else
#endif

void bsp_delay_us(uint32_t us)
{
    int i;
    for(i = 0; i < us; i++)
    {
//#define __NOP() __asm volatile("nop")
    #if (IW_SYSTEM_CLOCK == 80)
      //  73 times of nop has 1usec
      // 100
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();//__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      //__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      //__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
    #elif (IW_SYSTEM_CLOCK == 64)
      //  73 times of nop has 1usec
      // 100
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      __NOP();__NOP();__NOP();//__NOP();__NOP();//__NOP();__NOP();__NOP();__NOP();__NOP();
      //__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
      //__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
    #else
#error "please check your IW_SYSTEM_CLOCK!!!"
    #endif  // (IW_SYSTEM_CLOCK == 80)
    }
}

#if 0
void bsp_get_mcu_info(mcu_type_t *id)
{
	*id = MCU_TYPE_STM32L476;	
}
#endif

void bsp_init_mcu(void)
{
	HAL_Init();
	SystemClock_Config();
	#if defined(IOTWARE_BOARD)
    download_key_check();
	#elif defined(DISPOSAL_IOT_BOARD)
    #else
    #endif
}

void bsp_init_board(void)
{
#if defined(IOTWARE_BOARD)
	bsp_init_digital(PIN_RED_LED, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_GREEN_LED, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_BLUE_LED, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_TEMP_PWR_EN, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_CO2_PWR_EN, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_CO2_RESET, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_BLE_PWR_EN, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_LORA_PWR_EN, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_I2C2_SCL, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_I2C2_SDA, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_I2C3_SCL, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_I2C3_SDA, DIGITAL_OUTPUT_PUSHPULL);

	bsp_put_digital(PIN_BLE_PWR_EN, DIGITAL_LOW);
	bsp_put_digital(PIN_LORA_PWR_EN, DIGITAL_LOW);
	bsp_put_digital(PIN_TEMP_PWR_EN, DIGITAL_LOW);
	bsp_put_digital(PIN_CO2_RESET, DIGITAL_LOW);
	bsp_put_digital(PIN_CO2_PWR_EN, DIGITAL_LOW);
	
	bsp_put_digital(PIN_I2C2_SCL, DIGITAL_LOW);
	bsp_put_digital(PIN_I2C2_SDA, DIGITAL_LOW);
	bsp_put_digital(PIN_I2C3_SCL, DIGITAL_LOW);
	bsp_put_digital(PIN_I2C3_SDA, DIGITAL_LOW);

	bsp_put_digital(PIN_RED_LED, DIGITAL_HIGH);
	bsp_put_digital(PIN_GREEN_LED, DIGITAL_LOW);
	bsp_put_digital(PIN_BLUE_LED, DIGITAL_HIGH);
	//PRINTF("power gpio init\n");
#elif defined(DISPOSAL_IOT_BOARD)
	bsp_init_digital(PIN_LORA_RESET, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_LORA_POWER, DIGITAL_OUTPUT_PUSHPULL);
	bsp_init_digital(PIN_CO2_POWER, DIGITAL_OUTPUT_PUSHPULL);

	bsp_put_digital(PIN_LORA_RESET, DIGITAL_LOW);
	bsp_put_digital(PIN_LORA_POWER, DIGITAL_LOW);
	bsp_put_digital(PIN_CO2_POWER, DIGITAL_LOW);
#endif
}

static void Error_Handler(void)
{
	while(1);
}

#define EVT_UART_RX_DONE	0
#define EVT_UART_TX_DONE	1
#define EVT_UART_IO_ERROR	2

static void uart_event_handler(UART_HandleTypeDef *husart, int event);

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *husart)
{
	uart_event_handler( husart, EVT_UART_RX_DONE );
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *husart)
{
	uart_event_handler( husart, EVT_UART_TX_DONE );
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *husart)
{
	uart_event_handler( husart, EVT_UART_IO_ERROR );
}

/* USART1,USART2 init function */
static void MX_USART_Init(UART_HandleTypeDef *huart, uint32_t baud_rate)
{
	if(huart == &huart1)
	{
		huart1.Instance            = USART1;
		huart1.Init.BaudRate       = baud_rate;
		huart1.Init.WordLength     = USART_WORDLENGTH_8B;
		huart1.Init.StopBits       = USART_STOPBITS_1;
		huart1.Init.Parity         = USART_PARITY_NONE;
		huart1.Init.Mode           = USART_MODE_TX_RX;
		//huart1.Init.CLKPolarity    = USART_POLARITY_LOW;
		//huart1.Init.CLKPhase       = USART_PHASE_1EDGE;
		//huart1.Init.CLKLastBit     = USART_LASTBIT_DISABLE;
		huart1.Init.HwFlowCtl      = UART_HWCONTROL_NONE;
		huart1.Init.OverSampling   = UART_OVERSAMPLING_16;
		huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
		huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;

		if( HAL_UART_Init( &huart1 ) != HAL_OK )
		{
			Error_Handler();
		}
	}
	else if(huart == &huart2)
	{
		huart2.Instance            = USART2;
		huart2.Init.BaudRate       = baud_rate;
		huart2.Init.WordLength     = USART_WORDLENGTH_8B;
		huart2.Init.StopBits       = USART_STOPBITS_1;
		huart2.Init.Parity         = USART_PARITY_NONE;
		huart2.Init.Mode           = USART_MODE_TX_RX;
		//huart2.Init.CLKPolarity    = USART_POLARITY_LOW;
		//huart2.Init.CLKPhase       = USART_PHASE_1EDGE;
		//huart2.Init.CLKLastBit     = USART_LASTBIT_DISABLE;
		huart2.Init.HwFlowCtl      = UART_HWCONTROL_NONE;
		huart2.Init.OverSampling   = UART_OVERSAMPLING_16;
		huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
		huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;

		if( HAL_UART_Init( &huart2 ) != HAL_OK )
		{
			Error_Handler();
		}
	}
	else if(huart == &huart3)
	{
		huart3.Instance            = USART3;
		huart3.Init.BaudRate       = baud_rate;
		huart3.Init.WordLength     = USART_WORDLENGTH_8B;
		huart3.Init.StopBits       = USART_STOPBITS_1;
		huart3.Init.Parity         = USART_PARITY_NONE;
		huart3.Init.Mode           = USART_MODE_TX_RX;
		//huart3.Init.CLKPolarity    = USART_POLARITY_LOW;
		//huart3.Init.CLKPhase       = USART_PHASE_1EDGE;
		//huart3.Init.CLKLastBit     = USART_LASTBIT_DISABLE;
		huart3.Init.HwFlowCtl      = UART_HWCONTROL_NONE;
		huart3.Init.OverSampling   = UART_OVERSAMPLING_16;
		huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
		huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;

		if( HAL_UART_Init( &huart3 ) != HAL_OK )
		{
			Error_Handler();
		}
	}
}

void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
}

void HAL_I2C_MasterTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
	iw_irq_count += 1;
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
}

/* I2C2 init function */
static void MX_I2C2_Init(void)
{
	hi2c2.Instance              = I2C2;
	hi2c2.Init.Timing           = 0x109F2727;
	hi2c2.Init.OwnAddress1      = 0;
	hi2c2.Init.AddressingMode   = I2C_ADDRESSINGMODE_7BIT;
	hi2c2.Init.DualAddressMode  = I2C_DUALADDRESS_DISABLE;
	hi2c2.Init.OwnAddress2      = 0;
	hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
	hi2c2.Init.GeneralCallMode  = I2C_GENERALCALL_DISABLE;
	hi2c2.Init.NoStretchMode    = I2C_NOSTRETCH_DISABLE;

	if (HAL_I2C_Init( &hi2c2 ) != HAL_OK)
	{
		Error_Handler();
	}

	/**Configure Analogue filter */
	if (HAL_I2CEx_ConfigAnalogFilter( &hi2c2, I2C_ANALOGFILTER_ENABLE ) != HAL_OK )
	{
		Error_Handler();
	}

	/**Configure Digital filter */
	if (HAL_I2CEx_ConfigDigitalFilter( &hi2c2, 0 ) != HAL_OK )
	{
		Error_Handler();
	}
}

static GPIO_TypeDef* gGPIOBankAddress[BANK_GPIO_MAX]=
{
	GPIOA,
	GPIOB,
	GPIOC,
	GPIOD,
	GPIOE,
	GPIOF,
	GPIOG,
	GPIOH,
};

static uint16_t gGPIOPinSelect[PIN_GPIO_MAX]=
{
	GPIO_PIN_0,
	GPIO_PIN_1,
	GPIO_PIN_2,
	GPIO_PIN_3,
	GPIO_PIN_4,
	GPIO_PIN_5,
	GPIO_PIN_6,
	GPIO_PIN_7,
	GPIO_PIN_8,
	GPIO_PIN_9,
	GPIO_PIN_10,
	GPIO_PIN_11,
	GPIO_PIN_12,
	GPIO_PIN_13,
	GPIO_PIN_14,
	GPIO_PIN_15,
};


void bsp_toggle_gpio(uint8_t bank, uint8_t gpio) 
{
	HAL_GPIO_TogglePin(gGPIOBankAddress[bank], gGPIOPinSelect[gpio]);
}

void bsp_get_gpio(uint8_t bank, uint8_t gpio, uint8_t *val)
{
	*val = (uint8_t)HAL_GPIO_ReadPin(gGPIOBankAddress[bank], gGPIOPinSelect[gpio]);	
}


void bsp_set_gpio(uint8_t bank,  uint8_t  gpio, uint8_t val)
{
	HAL_GPIO_WritePin(gGPIOBankAddress[bank], gGPIOPinSelect[gpio], (GPIO_PinState)val);
}

void bsp_config_gpio(uint8_t bank, uint8_t gpio, uint8_t dir, uint8_t pull, uint32_t speed, uint8_t input, uint8_t drive, uint8_t sense)
{
    // uint8_t input, uint8_t drive, uint8_t sense : both are not used, for nordic
    
	GPIO_InitTypeDef GPIO_InitStruct;
  	/* Configure GPIO pin : PB6_Pin */
  	GPIO_InitStruct.Pin = gGPIOPinSelect[gpio];
  	GPIO_InitStruct.Mode = dir;
  	GPIO_InitStruct.Pull = pull;
  	GPIO_InitStruct.Speed = speed;	
  	HAL_GPIO_Init(gGPIOBankAddress[bank], &GPIO_InitStruct);
}

void bsp_init_gpio(void)
{
	//GPIO_InitTypeDef GPIO_InitStruct;

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();

	/* Configure GPIO pin Output Level */
	//HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
	//HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
#if 0
	/* Configure GPIO pin : B1_Pin */
	GPIO_InitStruct.Pin = GPIO_PIN_13; //B1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
	GPIO_InitStruct.Pull = GPIO_NOPULL;

	//HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
#endif

	/* Configure GPIO pins : PC2 PC3 PC4 PC5 PC6 PC7 PC8 PC9 */
	#if 0 // not used
	GPIO_InitStruct.Pin =
		  GPIO_PIN_2
		| GPIO_PIN_3
		| GPIO_PIN_4
		| GPIO_PIN_5 
	    | GPIO_PIN_6
		| GPIO_PIN_7
		| GPIO_PIN_8
		| GPIO_PIN_9
	;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;

	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/* Configure GPIO pins : PA0 PA1 PA4 PA6 PA7 PA8 PA11 PA12 PA15 */
	GPIO_InitStruct.Pin =
		  GPIO_PIN_0
		| GPIO_PIN_1
		| GPIO_PIN_4
		| GPIO_PIN_6 
	    | GPIO_PIN_7
		| GPIO_PIN_8
		| GPIO_PIN_11
		| GPIO_PIN_12 
	    | GPIO_PIN_15
	;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;

	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/* Configure GPIO pin : PA5 */
	GPIO_InitStruct.Pin   = GPIO_PIN_5; //LD2_Pin;
	GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull  = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;

	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/* Configure GPIO pins : PB0 PB1 PB2 PB12 PB4 PB6 PB7 PB8 PB9 */
	GPIO_InitStruct.Pin =
		  GPIO_PIN_0
		| GPIO_PIN_1
		| GPIO_PIN_2
		| GPIO_PIN_12 
	    | GPIO_PIN_4
		| GPIO_PIN_6
		| GPIO_PIN_7
		| GPIO_PIN_8 
	    | GPIO_PIN_9
	;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;

	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* Configure GPIO pin : PD2 */
	GPIO_InitStruct.Pin  = GPIO_PIN_2;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;

	HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

	// dcyang: PPG interrupt
	/* Configure GPIO pin : PB5 */
	GPIO_InitStruct.Pin  = GPIO_PIN_5; //MAX30102_INT_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
	GPIO_InitStruct.Pull = GPIO_PULLUP;

	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	#endif
	/* EXTI interrupt init */
	HAL_NVIC_SetPriority(EXTI9_5_IRQn, 5, 0);
	HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

void bsp_init_digital(uint8_t defined_pin, uint8_t mode)
{
	uint8_t bank = defined_pin >> 5;;
	uint8_t pin = defined_pin & 0x1f;
	uint8_t dir;
	uint8_t pull;


	if(DIGITAL_INPUT_NOPULL == mode) {
		dir = GPIO_MODE_INPUT;
		pull = GPIO_NOPULL;
	}
	else if(DIGITAL_INPUT_PULLUP == mode){
		dir = GPIO_MODE_INPUT;
		pull = GPIO_PULLUP;
	}
	else if(DIGITAL_INPUT_PULLDOWN == mode){
		dir = GPIO_MODE_INPUT;
		pull = GPIO_PULLDOWN;
	}
	else if(DIGITAL_OUTPUT_PUSHPULL == mode) {
		dir = GPIO_MODE_OUTPUT_PP;
		pull = GPIO_NOPULL;

	}
	else {
		dir = GPIO_MODE_OUTPUT_OD;
		pull = GPIO_NOPULL;
	}

	bsp_config_gpio(bank, pin, dir, pull, GPIO_SPEED_FREQ_HIGH, 0, 0, 0);
}

void bsp_put_digital(uint8_t defined_pin, uint8_t value)
{
	uint8_t bank = defined_pin >> 5;;
	uint8_t pin = defined_pin & 0x1f;
	bsp_set_gpio(bank, pin, value);
}

uint8_t bsp_get_digital(uint8_t defined_pin)
{
	uint8_t bank = defined_pin >> 5;;
	uint8_t pin = defined_pin & 0x1f;
	uint8_t value;
	bsp_get_gpio(bank, pin, &value);
	return value;
}

void bsp_toggle_digital(uint8_t defined_pin)
{
	uint8_t bank = defined_pin >> 5;;
	uint8_t pin = defined_pin & 0x1f;
	bsp_toggle_gpio(bank, pin);
}

typedef enum
{
    EVT_UART_DATA_READY,
    EVT_UART_FIFO_ERROR,
    EVT_UART_COMMUNICATION_ERROR,
    EVT_UART_TX_EMPTY,
    EVT_UART_DATA,

} uart_evt_t;

typedef struct
{
	void *pinst;
    uart_evt_t event;
    union
    {
        uint32_t error_communication;
        uint32_t error_code;
        uint8_t  value;
    } data;

} uart_status_t;

typedef void (*uart_event_handler_t)(uart_status_t * event);

typedef struct
{
	UART_HandleTypeDef *p_instance;
	uart_event_handler_t p_handler;
	uint8_t		tx_byte[1];
	uint8_t		rx_byte[1];
	iw_fifo_t	tx_fifo;
	uint8_t		tx_buf[256];
	iw_fifo_t	rx_fifo;
	uint8_t		rx_buf[256];
	volatile	bool m_rx_ovf;
	uint32_t	baud_rate;

} uart_instance_t;

static uart_instance_t gUart0Inst;
static uart_instance_t gUart1Inst;
static uart_instance_t gUart2Inst;


static void uart_event_handler(UART_HandleTypeDef *husart, int event)
{
	uart_instance_t *pinst = 0;


	if( husart == gUart0Inst.p_instance )
	{
		pinst = &gUart0Inst;
	}
	else if( husart == gUart1Inst.p_instance )
	{
		pinst = &gUart1Inst;
	}
	else if( husart == gUart2Inst.p_instance )
	{
		pinst = &gUart2Inst;
	}		
	else
	{
		return;
	}

	if( event == EVT_UART_RX_DONE )
	{
        // Write received byte to FIFO.
		uint32_t err_code;
		
        err_code = iw_put_fifo( &pinst->rx_fifo, pinst->rx_byte );

        if( err_code != IW_SUCCESS )
        {
     		uart_status_t einfo;

            einfo.pinst = pinst;
            einfo.event = EVT_UART_FIFO_ERROR;
            einfo.data.error_code = err_code;

            pinst->p_handler( &einfo );
        }
        // Notify that there are data available.
        else if( iw_count_fifo( &pinst->rx_fifo ) != 0 )
        {
     		uart_status_t einfo;

            einfo.pinst = pinst;
            einfo.event = EVT_UART_DATA_READY;

            pinst->p_handler( &einfo );
        }

        // Start new RX if size in buffer.
        if( iw_count_fifo( &pinst->rx_fifo ) <= sizeof(pinst->rx_buf) )
        {
			HAL_UART_Receive_IT( husart, pinst->rx_byte, 1 );
        }
        else
        {
            // Overflow in RX FIFO.
            pinst->m_rx_ovf = true;
        }
	}
	else if( event == EVT_UART_TX_DONE )
	{
		// Get next byte from FIFO.
		uint32_t err_code;
		
		err_code = iw_get_fifo( &pinst->tx_fifo, pinst->tx_byte );
		
		if( err_code  == IW_SUCCESS )
		{
			HAL_UART_Transmit_IT( husart, pinst->tx_byte, 1 );
		}
		else
		{
		    // Last byte from FIFO transmitted, notify the application.
     		uart_status_t einfo;

            einfo.pinst = pinst;
		    einfo.event = EVT_UART_TX_EMPTY;

		    pinst->p_handler( &einfo );
		}
	}
    else if( event == EVT_UART_IO_ERROR )
    {
 		uart_status_t einfo;

        einfo.pinst = pinst;
        einfo.event = EVT_UART_COMMUNICATION_ERROR;
        einfo.data.error_communication = 0; // TODO:

		HAL_UART_Receive_IT( husart, pinst->rx_byte, 1 );

        pinst->p_handler( &einfo );
    }
}

static void uart_user_event_handler( uart_status_t *p_event )
{
    switch (p_event->event)
    {
        case EVT_UART_DATA_READY:
        {
            break;
        }
        case EVT_UART_COMMUNICATION_ERROR:
        {
            break;
        }
        case EVT_UART_FIFO_ERROR:
        {
            break;
        }
        default:
        {
            break;
        }
    }
}

int bsp_init_uart( int port , uint32_t baud_rate)
{
	int r = -1;
	uart_instance_t *pinst = 0;

	if(port == BSP_UART1) {
		// USART0
		pinst = &gUart0Inst;
		pinst->p_instance = &huart1;
		pinst->baud_rate  = baud_rate;
		pinst->p_handler  = uart_user_event_handler;
	}
	else if(port == BSP_UART2) {
		// USART1
		pinst = &gUart1Inst;
		pinst->p_instance = &huart2;
		pinst->baud_rate = baud_rate;
		pinst->p_handler  = uart_user_event_handler;
	}
	else if(port == BSP_UART3) {
		// USART2
		pinst = &gUart2Inst;
		pinst->p_instance = &huart3;
		pinst->baud_rate = baud_rate;
		pinst->p_handler  = uart_user_event_handler;
	}

	if( pinst )
	{
		pinst->tx_byte[0] = 0;
		pinst->rx_byte[0] = 0;
		pinst->m_rx_ovf   = false;

		if(iw_init_fifo(&pinst->tx_fifo, pinst->tx_buf, 1, sizeof(pinst->tx_buf) ) != IW_SUCCESS) {
			return -1;
		}

		if(iw_init_fifo( &pinst->rx_fifo, pinst->rx_buf, 1, sizeof(pinst->rx_buf) ) != IW_SUCCESS) {
			return -1;
		}

		MX_USART_Init(pinst->p_instance, pinst->baud_rate);

		pinst->m_rx_ovf = false;
		HAL_UART_Receive_IT(pinst->p_instance, pinst->rx_byte, 1);

		r = 0;
	}

	return r;
}

int bsp_deinit_uart( int port )
{
	int r = -1;

	if( port == BSP_UART1 )
	{
		uart_instance_t *pinst = &gUart0Inst;
		HAL_UART_DeInit( pinst->p_instance );
		r = 0;
	}
	else if( port == BSP_UART2 )
	{
		uart_instance_t *pinst = &gUart1Inst;
		HAL_UART_DeInit( pinst->p_instance );
		r = 0;
	}
	else if( port == BSP_UART3 )
	{
		uart_instance_t *pinst = &gUart2Inst;
		HAL_UART_DeInit( pinst->p_instance );
		r = 0;
	}

	return r;
}

int bsp_getc_uart( int port, char *pch )
{
	int r = -1;

	*pch = -1;

	uart_instance_t *pinst = NULL;

	if( port == BSP_UART1 )
	{
		pinst = &gUart0Inst; // UART0
	}
	else if( port == BSP_UART2 )
	{
		pinst = &gUart1Inst; // UART1
	}
	else if( port == BSP_UART3 )
	{
		pinst = &gUart2Inst; // UART2
	}

	if( pinst )
	{
#if 1		
	    bool rx_ovf = pinst->m_rx_ovf;
		uint8_t ch = 0;

	    int err_code = iw_get_fifo( &pinst->rx_fifo, &ch );

	    if( rx_ovf )
	    {
	        pinst->m_rx_ovf = false;

			err_code = ( HAL_UART_Receive_IT( pinst->p_instance, pinst->rx_byte, 1 ) == HAL_OK ) ? IW_SUCCESS : IW_FAIL;
	    }
#else
		uint8_t ch = 0;
		int err_code = ( HAL_UART_Receive( pinst->p_instance, &ch, 1, 100) == HAL_OK ) ? IW_SUCCESS : IW_FAIL;
#endif
	    if( err_code == IW_SUCCESS )
	    {
	        if( pch ) *pch = (ch & 0xff);
			r = 0;
	    }
	}

	return r;
}

int bsp_putc_uart( int port, char ch )
{
	int r = -1;
	uart_instance_t *pinst = NULL;

    if( port == BSP_UART1 )
    {
      pinst = &gUart0Inst; // UART0
    }
    else if( port == BSP_UART2 )
    {
      pinst = &gUart1Inst; // UART1
    }
	else if( port == BSP_UART3 )
	{
      pinst = &gUart2Inst; // UART2
	}

	if( pinst )
	{
		uint8_t	onebyte = (uint8_t)(ch & 0xff);
#if 1
	    int err_code = IW_FAIL;

		while( err_code != IW_SUCCESS )
			err_code = iw_put_fifo( &pinst->tx_fifo, &onebyte );

	    if( err_code == IW_SUCCESS )
	    {
	        // The new byte has been added to FIFO. It will be picked up from there
	        // (in 'uart_event_handler') when all preceding bytes are transmitted.
	        // But if UART is not transmitting anything at the moment, we must start
	        // a new transmission here.
	        if( pinst->p_instance->gState == HAL_UART_STATE_READY )
	        {
	            // This operation should be almost always successful, since we've
	            // just added a byte to FIFO, but if some bigger delay occurred
	            // (some heavy interrupt handler routine has been executed) since
	            // that time, FIFO might be empty already.
	            if( iw_get_fifo( &pinst->tx_fifo, pinst->tx_byte ) == IW_SUCCESS )
	            {
					err_code = ( HAL_UART_Transmit_IT( pinst->p_instance, pinst->tx_byte, 1 ) == HAL_OK ) ? IW_SUCCESS : IW_FAIL;
	            }
	        }
	    }
#else
		int err_code = (HAL_UART_Transmit( pinst->p_instance, &onebyte, 1, 100) == HAL_OK) ? IW_SUCCESS : IW_FAIL;
#endif

		if( err_code == IW_SUCCESS )
		{
			r = 0;
		}
	}

	return r;
}

void bsp_printf(const char *format, ...)
{
	char str[256] = {0};
	va_list va;

	va_start(va, format);
	vsprintf(str, format, va);
	va_end(va);

	//__HAL_USART_SEND_REQ(gUart0Inst.p_instance, USART_TXDATA_FLUSH_REQUEST);
	//HAL_UART_AbortTransmit(gUart0Inst.p_instance);
	//HAL_UART_Transmit(gUart0Inst.p_instance, (uint8_t *)str, strlen(str), 100);
	int len = strlen(str);
	for(int i = 0; i < len; i++) {
		bsp_putc_uart(BSP_UART1, str[i]);
	}
}

/* added adc func by ys */
struct adc_gpio_info ADC12_GPIO[]={
	{BANK_GPIOC, PIN_GPIO0, ADC_CHANNEL_1},
	{BANK_GPIOC, PIN_GPIO1, ADC_CHANNEL_2},
	{BANK_GPIOC, PIN_GPIO2, ADC_CHANNEL_3},
	{BANK_GPIOC, PIN_GPIO3, ADC_CHANNEL_4},
	{BANK_GPIOC, PIN_GPIO4, ADC_CHANNEL_5},
	{BANK_GPIOA, PIN_GPIO1, ADC_CHANNEL_6},
	{BANK_GPIOA, PIN_GPIO2, ADC_CHANNEL_7},
	{BANK_GPIOA, PIN_GPIO3, ADC_CHANNEL_8},
	{BANK_GPIOA, PIN_GPIO4, ADC_CHANNEL_9},
	{BANK_GPIOA, PIN_GPIO5, ADC_CHANNEL_10},
	{BANK_GPIOA, PIN_GPIO6, ADC_CHANNEL_11},
	{BANK_GPIOA, PIN_GPIO7, ADC_CHANNEL_12},
	{BANK_GPIOC, PIN_GPIO4, ADC_CHANNEL_13},
	{BANK_GPIOC, PIN_GPIO5, ADC_CHANNEL_14},
	{BANK_GPIOB, PIN_GPIO0, ADC_CHANNEL_15},
	{BANK_GPIOB, PIN_GPIO1, ADC_CHANNEL_16},
};

struct adc_gpio_info ADC3_GPIO[]={
	{BANK_GPIOC, PIN_GPIO0, ADC_CHANNEL_1},
	{BANK_GPIOC, PIN_GPIO1, ADC_CHANNEL_2},
	{BANK_GPIOC, PIN_GPIO2, ADC_CHANNEL_3},
	{BANK_GPIOC, PIN_GPIO3, ADC_CHANNEL_4},
	{BANK_GPIOF, PIN_GPIO3, ADC_CHANNEL_6}, /* ADC3_IN6 */
	{BANK_GPIOF, PIN_GPIO4, ADC_CHANNEL_7},
	{BANK_GPIOF, PIN_GPIO5, ADC_CHANNEL_8},
	{BANK_GPIOF, PIN_GPIO6, ADC_CHANNEL_9},
	{BANK_GPIOF, PIN_GPIO7, ADC_CHANNEL_10},
	{BANK_GPIOF, PIN_GPIO8, ADC_CHANNEL_11},
	{BANK_GPIOF, PIN_GPIO9, ADC_CHANNEL_12},
	{BANK_GPIOF, PIN_GPIO10, ADC_CHANNEL_13}, /* ADC3_IN13 */
};

#define STM32_GET_ADC(n)	(n == 0 ? ADC1 : n == 1 ? ADC2 : ADC3)

/* Value of analog reference voltage (Vref+), connected to analog voltage   */
/* supply Vdda (unit: mV).                                                  */
#define VDDA_APPLI                       ((uint32_t)3413)

ADC_HandleTypeDef *gAdcHandle[BSP_ADC_MAX];
struct adc_hw_info gAdcHwinfo[BSP_ADC_MAX];
 

GPIO_TypeDef * stm32_get_adc_gpio_bank(ADC_HandleTypeDef *hadc)
{
	int i;
	GPIO_TypeDef *bank = NULL;

	for(i=0; i<BSP_ADC_MAX; i++){
		if(gAdcHwinfo[i].handle == hadc){
			bank = gAdcHwinfo[i].bank;
			break;
		}
	}
	return bank;
	
}

uint16_t stm32_get_adc_gpio_pin(ADC_HandleTypeDef *hadc)
{
	int i;
	uint16_t gpio = 0;
	for(i=0; i<BSP_ADC_MAX; i++){
		if(gAdcHwinfo[i].handle == hadc){
			gpio = gAdcHwinfo[i].gpio;
			break;
		}
	}
	return gpio;
}

uint32_t stm32_get_adc_irq(ADC_HandleTypeDef *hadc)
{
	unsigned irq;
	int i;
	uint8_t port = 0xff;

	for(i=0; i<BSP_ADC_MAX; i++){
		if(gAdcHwinfo[i].handle == hadc){
			port = gAdcHwinfo[i].port;
			break;
		}
	}
	
	if(port == 0 || port == 1)
		irq = ADC1_2_IRQn;
	else
		irq = ADC3_IRQn;
	return irq;
}

ADC_HandleTypeDef* stm32_get_adc_handle(uint8_t adc_num)
{
	return gAdcHwinfo[adc_num].handle;
}

void stm32_enable_adc_gpio_clk(ADC_HandleTypeDef *hadc)
{
	GPIO_TypeDef  * bank = stm32_get_adc_gpio_bank(hadc);
	if(bank == GPIOA)
		__HAL_RCC_GPIOA_CLK_ENABLE();
	else if(bank == GPIOB)
		__HAL_RCC_GPIOB_CLK_ENABLE();
	else if(bank == GPIOC)
		__HAL_RCC_GPIOC_CLK_ENABLE();
	else if(bank == GPIOF)
		__HAL_RCC_GPIOF_CLK_ENABLE();
	else{
		bsp_printf("%s fail\n", __func__);
	}
}


uint32_t stm32_get_adc_channel(uint8_t adc_num, uint8_t bank, uint8_t gpio)
{
	struct adc_gpio_info *ch_info = NULL;
	uint8_t len =0, i;
	uint32_t channel = 0;

	if(adc_num == 0 || adc_num == 1){
		ch_info = ADC12_GPIO;
		len = sizeof(ADC12_GPIO)/sizeof(struct adc_gpio_info);
	}
	else{
		ch_info = ADC3_GPIO;
		len = sizeof(ADC3_GPIO)/sizeof(struct adc_gpio_info);
	}

	for(i=0; i<len; i++){
		if(ch_info[i].bank == bank && ch_info[i].gpio == gpio){
			channel = ch_info[i].channel;
			break;
		}
		ch_info++;
	}
	//bsp_printf("adc ch:x%x\n", channel);
	return channel;
}

iw_error_t bsp_get_adc(uint8_t adc_num, uint16_t* val)
{
	HAL_ADC_Start(gAdcHwinfo[adc_num].handle);
	if(HAL_ADC_PollForConversion(gAdcHwinfo[adc_num].handle, 10) == HAL_OK) {
		*val = HAL_ADC_GetValue(gAdcHwinfo[adc_num].handle);
	}
	else {
		return IW_FAIL;
	}

	return IW_SUCCESS;
}

/* return voltage(mV) value */
iw_error_t bsp_get_voltage(uint8_t adc_num, uint16_t *voltage)
{
	uint16_t adc_val = 0;
	const float r1 = 3.9;
	const float r2 = 10.0;
	const float vcc = 3.3;

	if(bsp_get_adc(adc_num, &adc_val) == IW_SUCCESS) {
		//*voltage = (uint16_t)(__LL_ADC_CALC_DATA_TO_VOLTAGE(VDDA_APPLI, adc_val, LL_ADC_RESOLUTION_12B) * 1.5);
		*voltage = (uint16_t)((vcc * (float)adc_val / 4095.0) * ((r1 + r2) / r2) * 1000.0);
		//bsp_printf("bsp_get_voltage() %d %d\n", adc_val, *voltage);
		return IW_SUCCESS;
	}
	else {
		return IW_FAIL;
	}
}

/*static int Configure_ADC(void)*/
iw_error_t bsp_init_adc(uint8_t adc_num, uint8_t bank, uint8_t gpio)  
{
  ADC_ChannelConfTypeDef   sConfig;
  
	if(adc_num >= BSP_ADC_MAX)
		return IW_FAIL;
	
	gAdcHandle[adc_num] = iw_alloc(sizeof(ADC_HandleTypeDef));
	memset(gAdcHandle[adc_num], 0x0, sizeof(ADC_HandleTypeDef) );
	
	gAdcHwinfo[adc_num].handle = gAdcHandle[adc_num];
	gAdcHwinfo[adc_num].port = adc_num;
	gAdcHwinfo[adc_num].bank = gGPIOBankAddress[bank];
	gAdcHwinfo[adc_num].gpio = gGPIOPinSelect[gpio];

	/*## Configuration of ADC ##################################################*/

	/*## Configuration of ADC hierarchical scope: ##############################*/
	/*## common to several ADC, ADC instance, ADC group regular  ###############*/

	/* Set ADC instance of HAL ADC handle AdcHandle */
	gAdcHandle[adc_num]->Instance = STM32_GET_ADC(adc_num);
	/* Configuration of HAL ADC handle init structure:                          */
	/* parameters of scope ADC instance and ADC group regular.                  */
	/* Note: On this STM32 family, ADC group regular sequencer is               */
	/*       fully configurable: sequencer length and each rank                 */
	/*       affectation to a channel are configurable.                         */
	gAdcHandle[adc_num]->Init.ClockPrescaler        = ADC_CLOCK_SYNC_PCLK_DIV2;
	gAdcHandle[adc_num]->Init.Resolution            = ADC_RESOLUTION_12B;
	gAdcHandle[adc_num]->Init.DataAlign             = ADC_DATAALIGN_RIGHT;
	gAdcHandle[adc_num]->Init.ScanConvMode          = ADC_SCAN_DISABLE;              /* Sequencer disabled (ADC conversion on only 1 channel: channel set on rank 1) */
	gAdcHandle[adc_num]->Init.EOCSelection          = ADC_EOC_SINGLE_CONV;
	gAdcHandle[adc_num]->Init.LowPowerAutoWait      = DISABLE;
	gAdcHandle[adc_num]->Init.ContinuousConvMode    = DISABLE;                       /* Continuous mode disabled to have only 1 conversion at each conversion trig */
	gAdcHandle[adc_num]->Init.NbrOfConversion       = 1;                             /* Parameter discarded because sequencer is disabled */
	gAdcHandle[adc_num]->Init.DiscontinuousConvMode = DISABLE;                       /* Parameter discarded because sequencer is disabled */
	gAdcHandle[adc_num]->Init.NbrOfDiscConversion   = 1;                             /* Parameter discarded because sequencer is disabled */
	gAdcHandle[adc_num]->Init.ExternalTrigConv      = ADC_SOFTWARE_START;            /* Software start to trig the 1st conversion manually, without external event */
	gAdcHandle[adc_num]->Init.DMAContinuousRequests = DISABLE;                       /* ADC with DMA transfer: continuous requests to DMA disabled (default state) since DMA is not used in this example. */
	gAdcHandle[adc_num]->Init.Overrun               = ADC_OVR_DATA_OVERWRITTEN;

	if (HAL_ADC_Init(gAdcHandle[adc_num]) != HAL_OK)
	{
		/* ADC initialization error */
		return IW_FAIL;
	}
  	
	/*## Configuration of ADC hierarchical scope: ##############################*/
	/*## ADC group injected and channels mapped on group injected ##############*/

	/* Note: ADC group injected not used and not configured in this example.    */
	/*       Refer to other ADC examples using this feature.                    */
	/* Note: Call of the functions below are commented because they are         */
	/*       useless in this example:                                           */
	/*       setting corresponding to default configuration from reset state.   */


	/*## Configuration of ADC hierarchical scope: ##############################*/
	/*## channels mapped on group regular         ##############################*/

	/* Configuration of channel on ADCx regular group on sequencer rank 1 */
	/* Note: On this STM32 family, ADC group regular sequencer is               */
	/*       fully configurable: sequencer length and each rank                 */
	/*       affectation to a channel are configurable.                         */
	/* Note: Considering IT occurring after each ADC conversion                 */
	/*       (IT by ADC group regular end of unitary conversion),               */
	/*       select sampling time and ADC clock with sufficient                 */
	/*       duration to not create an overhead situation in IRQHandler.        */
	sConfig.Channel      = stm32_get_adc_channel(adc_num, bank, gpio);/* ADC channel selection */
	sConfig.Rank         = ADC_REGULAR_RANK_1;          /* ADC group regular rank in which is mapped the selected ADC channel */
	sConfig.SamplingTime = ADC_SAMPLETIME_47CYCLES_5;
	sConfig.SingleDiff   = ADC_SINGLE_ENDED;            /* ADC channel differential mode */
	sConfig.OffsetNumber = ADC_OFFSET_NONE;             /* ADC channel affected to offset number */
	sConfig.Offset       = 0;                           /* Parameter discarded because offset correction is disabled */

	if (HAL_ADC_ConfigChannel(gAdcHandle[adc_num], &sConfig) != HAL_OK)
	{
		/* Channel Configuration Error */
		return IW_FAIL;
	}
	return IW_SUCCESS;
}

iw_error_t bsp_deinit_adc(uint8_t adc_num)
{
	HAL_ADC_DeInit(stm32_get_adc_handle(adc_num));
	return IW_SUCCESS;
}


iw_error_t bsp_init_analog(uint8_t adc_num, uint8_t defined_pin)
{
	uint8_t bank = defined_pin >> 5;
	uint8_t pin = defined_pin & 0x1f;

	return bsp_init_adc(adc_num, bank, pin);
}

iw_error_t bsp_deinit_analog(uint8_t adc_num)
{
	return bsp_deinit_adc(adc_num);
}

uint16_t bsp_get_analog(uint8_t adc_num)
{
	uint16_t value = 0;
	if(bsp_get_adc(adc_num, &value) == IW_FAIL) {
		value = -1;
	}
	return value;
}


/* I2C3 init function */
static void MX_I2C3_Init(void)
{
	hi2c3.Instance              = I2C3;
	hi2c3.Init.Timing           = 0x10909CEC;
	hi2c3.Init.OwnAddress1      = 0;
	hi2c3.Init.AddressingMode   = I2C_ADDRESSINGMODE_7BIT;
	hi2c3.Init.DualAddressMode  = I2C_DUALADDRESS_DISABLE;
	hi2c3.Init.OwnAddress2      = 0;
	hi2c3.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
	hi2c3.Init.GeneralCallMode  = I2C_GENERALCALL_DISABLE;
	hi2c3.Init.NoStretchMode    = I2C_NOSTRETCH_DISABLE;

	if( HAL_I2C_Init( &hi2c3 ) != HAL_OK )
	{
		Error_Handler();
	}

	/**Configure Analogue filter */
	if( HAL_I2CEx_ConfigAnalogFilter( &hi2c3, I2C_ANALOGFILTER_ENABLE ) != HAL_OK )
	{
		Error_Handler();
	}

	/**Configure Digital filter */
	if( HAL_I2CEx_ConfigDigitalFilter( &hi2c3, 0 ) != HAL_OK )
	{
		Error_Handler();
	}
}

#define STM32_SPI_RX_DONE		0
#define STM32_SPI_TX_DONE		1
#define STM32_SPI_IO_ERROR	2

static void stm32_spi_event_handler(SPI_HandleTypeDef *hspi, int event);

void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
	stm32_spi_event_handler( hspi, STM32_SPI_RX_DONE );
}

void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi)
{
	stm32_spi_event_handler( hspi, STM32_SPI_TX_DONE );
}

void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi)
{
	stm32_spi_event_handler( hspi, STM32_SPI_IO_ERROR );
}


static I2C_HandleTypeDef *i2c_inst[BSP_I2C_MAX] =
{
	NULL,
	&hi2c2,
	&hi2c3,	
};
#define I2C_RETRY_NUM (0x1Fu)
int bsp_init_i2c(uint8_t  port)
{
	int ret = -1;
	if(BSP_I2C1 == port) {

	}
	else if(BSP_I2C2 == port) {
		MX_I2C2_Init();
		ret = 0;
	}
	else if(BSP_I2C3 == port) {
		MX_I2C3_Init();
		ret = 0;
	}
	else {

	}
	return ret;
#if 0
	if ( port == 3 ){
		MX_I2C3_Init();
	}else if ( port == 2 ){
		MX_I2C2_Init();
	}else{
		bsp_printf("CHECK I2C PORT(%d)\n", port);
		return -1;
	}

	return 0;
#endif	
}

int bsp_deinit_i2c(uint8_t port)
{
	int ret = -1;
	if(BSP_I2C1 == port) {

	}
	else if(BSP_I2C2 == port) {
		HAL_I2C_DeInit(&hi2c2);
		ret = 0;
	}
	else if(BSP_I2C3 == port) {
		HAL_I2C_DeInit(&hi2c3);
		ret = 0;
	}
	else {

	}
	return ret;
#if 0	
	if ( port == 3 ){
		HAL_I2C_DeInit( &hi2c3); // SENSOR
	}else if ( port == 2 ){
		HAL_I2C_DeInit( &hi2c2); 
	}else{
		bsp_printf("CHECK I2C PORT(%d)\n", port);
		return -1;
	}
	return 0;
#endif
}

int bsp_xfer_i2c(bsp_i2c_msg_t *msg, uint32_t num)
{
	int status = 0;
	int retry = I2C_RETRY_NUM;
	uint32_t error;
	
	for(int i = 0; i < num && status == 0; i++) {
		I2C_HandleTypeDef *pinst;
		pinst = i2c_inst[ msg[i].port ];
		
		if( msg[i].tx_len > 0 &&  msg[i].tx_buf ) {
			do {
#if 0				
				if( HAL_I2C_Master_Transmit_IT( pinst, msg[i].addr, msg[i].tx_buf, msg[i].tx_len ) == HAL_OK)
				{
					while (HAL_I2C_GetState(pinst) != HAL_I2C_STATE_READY);
					status = 0;
				}		
#else
				HAL_I2C_Master_Transmit(pinst, msg[i].addr, msg[i].tx_buf, msg[i].tx_len, 10);
#endif
				error = HAL_I2C_GetError(pinst);								
				if(error == HAL_I2C_ERROR_NONE) break;
				
				//bsp_printf("bsp_xfer_i2c(tx) try(%d)\n", retry);
				//iw_delay_us(1);
				iw_sleep(1);
			} while(retry--);
			
			if( error != HAL_I2C_ERROR_NONE ){
				//bsp_printf("error:x%x", error);		
				return -1;	
			}
		}	

		retry = I2C_RETRY_NUM;
		if(msg[i].rx_len > 0 &&  msg[i].rx_buf) {
			do {
#if 0				
				if(HAL_I2C_Master_Receive_IT( pinst, msg[i].addr, msg[i].rx_buf, msg[i].rx_len ) == HAL_OK) {
					while (HAL_I2C_GetState(pinst) != HAL_I2C_STATE_READY);
					status = 0;
				}
#else
				HAL_I2C_Master_Receive(pinst, msg[i].addr, msg[i].rx_buf, msg[i].rx_len, 10);
#endif
				error = HAL_I2C_GetError(pinst);
				if(error == HAL_I2C_ERROR_NONE) break;

				//bsp_printf("bsp_xfer_i2c(rx) try(%d)\n", retry);
				//iw_delay_us(1);
				iw_sleep(1);
			} while(retry--);
			
			if( error != HAL_I2C_ERROR_NONE ){
				bsp_printf("bsp_xfer_i2c() err x%02X\n", error);
				return -1;
			}
		}
	}

	//bsp_printf("bsp_xfer_i2c() ret %d\n", status);
	return status;
}

typedef struct
{
	SPI_HandleTypeDef *instance;
	volatile bool xfer_done;

} stm32_spi_inst_t;

static stm32_spi_inst_t spi_inst[2];

static void stm32_spi_event_handler(SPI_HandleTypeDef *hspi, int event)
{
 	if( event == STM32_SPI_RX_DONE )
	{

		if( hspi->Instance == SPI3 )
		{
	   		spi_inst[ 0 ].xfer_done = true;
		}
		else if( hspi->Instance == SPI2 )
		{
	    	spi_inst[ 1 ].xfer_done = true;
		}
	}
	else if( event == STM32_SPI_TX_DONE )
	{
		if( hspi->Instance == SPI3 )
		{
	   		spi_inst[ 0 ].xfer_done = true;
		}
		else if( hspi->Instance == SPI2 )
		{
	    	spi_inst[ 1 ].xfer_done = true;
		}
	}
	else if( event == STM32_SPI_IO_ERROR )
	{
	}
}

int bsp_init_spi(uint8_t port)
{
	int r = -1;

	if( port == BSP_SPI1 )
	{
		spi_inst[ 0 ].instance = &hspi3;
		r = 0;
	}
	else if( port == BSP_SPI2 )
	{
		spi_inst[ 1 ].instance = &hspi2;
		r = 0;
	}

	return r;
}

int bsp_deinit_spi(uint8_t port)
{
	int r = -1;

	if( port == BSP_SPI1 )
	{
		r = 0;
	}
	else if( port == BSP_SPI2 )
	{
		r = 0;
	}

	return r;
}

int bsp_xfer_spi(bsp_spi_msg_t *msg, int num)
{
	int r = 0;

	for( int i = 0; i < num && r == 0; i++ )
	{
		stm32_spi_inst_t *pinst = &spi_inst[ msg[i].port ];

		if( msg[i].tx_buf && msg[i].tx_len > 0 )
		{
			if( HAL_SPI_Transmit_IT( pinst->instance, msg[i].tx_buf, msg[i].tx_len ) != HAL_OK )
			{
				r = -1;
				continue;
			}
			while( HAL_SPI_GetState( pinst->instance ) != HAL_SPI_STATE_READY );
		}
		if( msg[i].rx_buf && msg[i].rx_len > 0 )
		{
			if( HAL_SPI_Receive_IT( pinst->instance, msg[i].rx_buf, msg[i].rx_len ) != HAL_OK )	
			{
				r = -1;
				continue;
			}
			while( HAL_SPI_GetState( pinst->instance ) != HAL_SPI_STATE_READY );
		}
		r = 0;
	}
	
	return r;
}
