#ifndef __IW_ERROR_H
#define __IW_ERROR_H

/* Return values for any IoTware function */
typedef enum iw_error {
    IW_SUCCESS = 0, /* Return on success */
    IW_FAIL = -1,   /* Return on error */
} iw_error_t;

#endif /* __IW_ERROR_H */
